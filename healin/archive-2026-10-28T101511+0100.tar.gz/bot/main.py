import asyncio
import os
import pathlib

import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = os.getenv("PREFIX", "-")

# All three privileged intents below must also be switched on in the Developer Portal
# (Bot > Privileged Gateway Intents), or the bot refuses to connect.
intents = discord.Intents.default()
intents.message_content = True  # needed for prefix commands
intents.members = True  # needed for role limits
intents.presences = True  # needed for Vanity (reads custom statuses)


class Bot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=commands.when_mentioned_or(PREFIX),
            intents=intents,
            help_command=None,  # custom help lives in cogs/general.py
            case_insensitive=True,
        )
        self.bot_name = os.getenv("BOT_NAME", "heal")
        self.prefix_display = PREFIX
        self.credit = os.getenv("CODED_BY", "")

    async def setup_hook(self):
        for path in sorted(pathlib.Path("cogs").glob("*.py")):
            if path.stem.startswith("_"):
                continue
            try:
                await self.load_extension(f"cogs.{path.stem}")
                print(f"loaded cogs.{path.stem}")
            except Exception as e:
                print(f"FAILED cogs.{path.stem}: {e!r}")

    async def on_ready(self):
        print(f"Logged in as {self.user} ({self.user.id})")


async def main():
    if not TOKEN:
        raise SystemExit("Set DISCORD_TOKEN in your .env file")
    async with Bot() as bot:
        await bot.start(TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
