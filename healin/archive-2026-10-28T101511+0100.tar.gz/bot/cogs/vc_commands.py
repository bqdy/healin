"""
VoiceMaster cog for discord.py 2.4+   ->   save as  cogs/voicemaster.py
(replace your current cogs/voicemaster.py with this one)

Needs:   pip install -U discord.py
Intents: Server Members + Voice States (+ Message Content for prefix commands)
Data:    voicemaster_data.json (created next to the bot)

How it works
- Joining a hub (primary / secondary) creates a personal voice channel and moves you in.
  The channel is deleted when it empties.
- Hub 1 uses category slot 1, hub 2 uses slot 2 (falls back to slot 1, then the hub's own category).
- Random hub: joining it drops you into a random voice channel in the allowed categories.
- Auto-unmute channels: anyone who joins gets their server-mute removed.
"""
import json
import os
import random
import time
import traceback
import asyncio
from typing import Optional

import discord
from discord.ext import commands

DATA_FILE = "voicemaster_data.json"
DEFAULT_NAME = "{user}'s VC"
MAX_CATEGORIES = 10

db = {}
if os.path.exists(DATA_FILE):
    try:
        with open(DATA_FILE) as f:
            db = json.load(f)
    except (OSError, json.JSONDecodeError):
        print("[voicemaster] could not read voicemaster_data.json, starting fresh")


def save():
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(db, f, indent=2)
    os.replace(tmp, DATA_FILE)


def conf(guild_id) -> dict:
    c = db.setdefault(str(guild_id), {})
    c.setdefault("hub", None)
    c.setdefault("hub2", None)
    c.setdefault("randomhub", None)
    c.setdefault("randomcats", [])
    c.setdefault("categories", [])   # [{"id": int|None, "prefix": str, "sequential": bool}]
    c.setdefault("default_name", DEFAULT_NAME)
    c.setdefault("autounmute", [None, None])
    c.setdefault("temp", {})         # channel_id -> {"owner": int, "cat": int|None, "num": int|None}
    return c


async def send(ctx, content=None, **kwargs):
    kwargs.setdefault("allowed_mentions", discord.AllowedMentions.none())
    return await ctx.send(content, **kwargs)


def staff():
    async def predicate(ctx):
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        if ctx.author.guild_permissions.manage_guild or ctx.author.guild_permissions.administrator:
            return True
        raise commands.MissingPermissions(["manage_guild"])
    return commands.check(predicate)


def owner_check():
    """Server owner or bot owner."""
    async def predicate(ctx):
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        if ctx.author == ctx.guild.owner or await ctx.bot.is_owner(ctx.author):
            return True
        raise commands.CheckFailure("Only the server owner or bot owner can manage VoiceMaster categories.")
    return commands.check(predicate)


def parse_on(text: str) -> bool:
    t = text.lower()
    if t in ("on", "true", "enable", "yes"):
        return True
    if t in ("off", "false", "disable", "no"):
        return False
    raise commands.BadArgument("Use on or off.")


class NumberModal(discord.ui.Modal, title="Set user limit"):
    value = discord.ui.TextInput(label="Limit (0 = no limit, max 99)", max_length=2)

    def __init__(self, channel: discord.VoiceChannel):
        super().__init__()
        self.channel = channel

    async def on_submit(self, interaction: discord.Interaction):
        try:
            n = int(self.value.value)
            if not 0 <= n <= 99:
                raise ValueError
        except ValueError:
            return await interaction.response.send_message("Enter a number from 0 to 99.", ephemeral=True)
        await self.channel.edit(user_limit=n or None, reason="VoiceMaster limit")
        await interaction.response.send_message(f"👥 Limit set to {n or 'no limit'}.", ephemeral=True)


class NameModal(discord.ui.Modal, title="Rename channel"):
    value = discord.ui.TextInput(label="New name", max_length=100)

    def __init__(self, channel: discord.VoiceChannel):
        super().__init__()
        self.channel = channel

    async def on_submit(self, interaction: discord.Interaction):
        name = self.value.value[:100]
        await self.channel.edit(name=name, reason="VoiceMaster rename")
        await interaction.response.send_message(f"✏️ Renamed to **{name}**.", ephemeral=True)


class PanelView(discord.ui.View):
    """Buttons shown in each temp VC's chat. Only the channel owner can press them."""

    def __init__(self):
        super().__init__(timeout=None)

    async def _is_owner(self, interaction: discord.Interaction) -> bool:
        entry = conf(interaction.guild_id)["temp"].get(str(interaction.channel_id))
        if not entry or entry["owner"] != interaction.user.id:
            await interaction.response.send_message(
                "Only the channel owner can use these buttons.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Lock", emoji="🔒", style=discord.ButtonStyle.secondary, row=0, custom_id="vm:lock")
    async def lock(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._is_owner(interaction):
            return
        await interaction.channel.set_permissions(interaction.guild.default_role, connect=False,
                                                  reason="VoiceMaster lock")
        await interaction.response.send_message("🔒 Locked.", ephemeral=True)

    @discord.ui.button(label="Unlock", emoji="🔓", style=discord.ButtonStyle.secondary, row=0, custom_id="vm:unlock")
    async def unlock(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._is_owner(interaction):
            return
        await interaction.channel.set_permissions(interaction.guild.default_role, connect=None,
                                                  reason="VoiceMaster unlock")
        await interaction.response.send_message("🔓 Unlocked.", ephemeral=True)

    @discord.ui.button(label="Hide", emoji="🙈", style=discord.ButtonStyle.secondary, row=0, custom_id="vm:hide")
    async def hide(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._is_owner(interaction):
            return
        await interaction.channel.set_permissions(interaction.guild.default_role, view_channel=False,
                                                  reason="VoiceMaster hide")
        await interaction.response.send_message("🙈 Hidden.", ephemeral=True)

    @discord.ui.button(label="Show", emoji="👀", style=discord.ButtonStyle.secondary, row=0, custom_id="vm:show")
    async def show(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._is_owner(interaction):
            return
        await interaction.channel.set_permissions(interaction.guild.default_role, view_channel=None,
                                                  reason="VoiceMaster show")
        await interaction.response.send_message("👀 Visible again.", ephemeral=True)

    @discord.ui.button(label="Limit", emoji="👥", style=discord.ButtonStyle.secondary, row=0, custom_id="vm:limit")
    async def limit(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._is_owner(interaction):
            return
        await interaction.response.send_modal(NumberModal(interaction.channel))

    @discord.ui.button(label="Rename", emoji="✏️", style=discord.ButtonStyle.secondary, row=1, custom_id="vm:rename")
    async def rename(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._is_owner(interaction):
            return
        await interaction.response.send_modal(NameModal(interaction.channel))


class VoiceMaster(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.last_create = {}

    # ---- lifecycle -------------------------------------------------------
    async def cog_load(self):
        try:
            self.bot.add_view(PanelView())   # buttons keep working after restarts
        except ValueError as e:
            print(f"[voicemaster] panels won't survive restarts: {e}")
        # Drop temp channels that emptied or vanished while the bot was offline.
        for gid, c in list(db.items()):
            guild = self.bot.get_guild(int(gid))
            for cid in list(c.get("temp", {})):
                ch = guild.get_channel(int(cid)) if guild else None
                if ch is None:
                    c["temp"].pop(cid, None)
                elif not ch.members:
                    try:
                        await ch.delete(reason="VoiceMaster cleanup")
                    except discord.HTTPException:
                        pass
                    c["temp"].pop(cid, None)
        save()

    async def cog_check(self, ctx):
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        return True

    async def cog_command_error(self, ctx, error):
        error = getattr(error, "original", error)
        if isinstance(error, commands.CommandNotFound):
            return
        if isinstance(error, commands.MissingPermissions):
            msg = "You don't have permission to use that."
        elif isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument,
                                commands.TooManyArguments, commands.BadUnionArgument)):
            msg = f"Usage: `{ctx.clean_prefix}{ctx.command.qualified_name} {ctx.command.signature}`"
        elif isinstance(error, discord.Forbidden):
            msg = "I'm missing permissions or my role is too low for that."
        elif isinstance(error, commands.NoPrivateMessage):
            msg = "Server only."
        elif isinstance(error, commands.CheckFailure):
            msg = str(error) or "You can't use that here."
        else:
            traceback.print_exception(type(error), error, error.__traceback__)
            msg = f"Something went wrong: `{error}`"
        await send(ctx, msg)

    # ======================================================================
    # VOICE LOGIC
    # ======================================================================
    def slot_category(self, guild, c, slot: int, hub: discord.VoiceChannel):
        """Return (category_channel_or_None, slot_index_or_None) for a hub."""
        cats = c["categories"]
        for idx in (slot - 1, 0):
            if 0 <= idx < len(cats) and cats[idx].get("id"):
                cat = guild.get_channel(cats[idx]["id"])
                if isinstance(cat, discord.CategoryChannel):
                    return cat, idx
        return hub.category, None

    def render_name(self, member, c, idx) -> tuple:
        template = c["default_name"] or DEFAULT_NAME
        name = (template.replace("{user}", member.display_name)
                .replace("{username}", member.name)
                .replace("{display}", member.display_name))
        prefix, num = "", None
        if idx is not None:
            slot = c["categories"][idx]
            prefix = slot.get("prefix") or ""
            if slot.get("sequential"):
                used = {t.get("num") for t in c["temp"].values()
                        if t.get("cat") == slot.get("id") and t.get("num")}
                num = 1
                while num in used:
                    num += 1
        parts = [prefix, f"{num}" if num else "", name]
        return " ".join(p for p in parts if p).strip()[:100] or "VC", num

    async def create_vc(self, member, c, slot: int, hub):
        now = time.time()
        if now - self.last_create.get(member.id, 0) < 3:   # anti join-spam
            return
        self.last_create[member.id] = now
        guild = member.guild
        cat, idx = self.slot_category(guild, c, slot, hub)
        name, num = self.render_name(member, c, idx)
        ow = dict(cat.overwrites) if cat else {}
        ow[member] = discord.PermissionOverwrite(view_channel=True, connect=True,
                                                 manage_channels=True, move_members=True)
        try:
            ch = await guild.create_voice_channel(name, category=cat, overwrites=ow,
                                                  reason=f"VoiceMaster: {member}")
            c["temp"][str(ch.id)] = {"owner": member.id, "cat": cat.id if cat else None, "num": num}
            save()
            await member.move_to(ch)
            embed = discord.Embed(
                title="🎙️ Your voice channel",
                description=f"{member.mention}, use the buttons below to manage **{ch.name}**.",
                color=0x5865F2)
            await ch.send(content=member.mention, embed=embed, view=PanelView(),
                          allowed_mentions=discord.AllowedMentions(users=[member]))
        except discord.HTTPException:
            # couldn't move them (they left?) -> tidy up
            ch = locals().get("ch")
            if ch:
                c["temp"].pop(str(ch.id), None)
                save()
                try:
                    await ch.delete()
                except discord.HTTPException:
                    pass

    async def random_join(self, member, c):
        guild = member.guild
        hubs = {c["hub"], c["hub2"], c["randomhub"]}
        pool = []
        for cid in c["randomcats"]:
            cat = guild.get_channel(cid)
            if isinstance(cat, discord.CategoryChannel):
                pool += [v for v in cat.voice_channels if v.id not in hubs
                         and v.permissions_for(member).connect]
        busy = [v for v in pool if v.members]
        target = random.choice(busy or pool) if pool else None
        try:
            await member.move_to(target)   # None disconnects if there is nowhere to go
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if member.bot:
            return
        c = conf(member.guild.id)
        if after.channel and after.channel != before.channel:
            cid = after.channel.id
            if cid == c["hub"]:
                await self.create_vc(member, c, 1, after.channel)
            elif cid == c["hub2"]:
                await self.create_vc(member, c, 2, after.channel)
            elif cid == c["randomhub"]:
                await self.random_join(member, c)
            if cid in [x for x in c["autounmute"] if x] and after.mute:
                try:
                    await member.edit(mute=False, reason="VoiceMaster auto-unmute")
                except discord.HTTPException:
                    pass
        if before.channel and before.channel != after.channel:
            if str(before.channel.id) in c["temp"] and not before.channel.members:
                c["temp"].pop(str(before.channel.id), None)
                save()
                try:
                    await before.channel.delete(reason="VoiceMaster: channel empty")
                except discord.HTTPException:
                    pass

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        c = db.get(str(channel.guild.id))
        if not c:
            return
        changed = c.get("temp", {}).pop(str(channel.id), None) is not None
        for key in ("hub", "hub2", "randomhub"):
            if c.get(key) == channel.id:
                c[key] = None
                changed = True
        if channel.id in c.get("autounmute", []):
            c["autounmute"] = [None if x == channel.id else x for x in c["autounmute"]]
            changed = True
        if changed:
            save()

    # ======================================================================
    # COMMANDS
    # ======================================================================
    @commands.group(name="vm", invoke_without_command=True)
    @staff()
    async def vm(self, ctx):
        p = ctx.clean_prefix + "vm"
        c = conf(ctx.guild.id)

        def ch(i):
            return f"<#{i}>" if i else "not set"

        await send(ctx, embed=discord.Embed(
            title="VoiceMaster",
            description=(
                f"**Setup:** `{p} setup` · `{p} hub set|create` · `{p} hub2 set|create|remove`\n"
                f"**Categories (owner):** `{p} category add|remove|set|list|prefix|sequential`\n"
                f"**Default name:** `{p} default name [template]` (`{{user}}`, `{{username}}`)\n"
                f"**Random hub:** `{p} randomhub set` · `{p} randomhub category add|remove`\n"
                f"**Auto-unmute:** `{p} autounmute set` · `{p} autounmute2 set`\n\n"
                f"Hub: {ch(c['hub'])} · Hub 2: {ch(c['hub2'])} · Random: {ch(c['randomhub'])}\n"
                f"Template: `{c['default_name']}`")))

    # ---- setup / hubs -------------------------------------------------------
    @vm.command(name="setup")
    @staff()
    async def vm_setup(self, ctx):
        c = conf(ctx.guild.id)
        cat = None
        if c["categories"] and c["categories"][0].get("id"):
            cat = ctx.guild.get_channel(c["categories"][0]["id"])
        if not isinstance(cat, discord.CategoryChannel):
            cat = await ctx.guild.create_category("VoiceMaster", reason="VoiceMaster setup")
            if c["categories"]:
                c["categories"][0]["id"] = cat.id
            else:
                c["categories"].append({"id": cat.id, "prefix": "", "sequential": False})
        hub = await ctx.guild.create_voice_channel("Join to Create", category=cat,
                                                   reason="VoiceMaster setup")
        c["hub"] = hub.id
        save()
        await send(ctx, f"✅ VoiceMaster ready. Join {hub.mention} to get your own channel "
                        f"(category: **{cat.name}**, slot 1).")

    @vm.group(name="hub", invoke_without_command=True)
    @staff()
    async def vm_hub(self, ctx):
        await send(ctx, f"Usage: `{ctx.clean_prefix}vm hub set <channelID>` or "
                        f"`{ctx.clean_prefix}vm hub create [name]`")

    @vm_hub.command(name="set")
    @staff()
    async def vm_hub_set(self, ctx, channel: discord.VoiceChannel):
        conf(ctx.guild.id)["hub"] = channel.id
        save()
        await send(ctx, f"✅ Primary hub is now {channel.mention}.")

    @vm_hub.command(name="create")
    @staff()
    async def vm_hub_create(self, ctx, *, name: str = "Join to Create"):
        c = conf(ctx.guild.id)
        cat = None
        if c["categories"] and c["categories"][0].get("id"):
            cat = ctx.guild.get_channel(c["categories"][0]["id"])
        ch = await ctx.guild.create_voice_channel(name[:100], category=cat if isinstance(cat, discord.CategoryChannel) else None)
        c["hub"] = ch.id
        save()
        await send(ctx, f"✅ Created primary hub {ch.mention}.")

    @vm.group(name="hub2", invoke_without_command=True)
    @staff()
    async def vm_hub2(self, ctx):
        await send(ctx, f"Usage: `{ctx.clean_prefix}vm hub2 set <channelID>` · `create [name]` · `remove`")

    @vm_hub2.command(name="set")
    @staff()
    async def vm_hub2_set(self, ctx, channel: discord.VoiceChannel):
        conf(ctx.guild.id)["hub2"] = channel.id
        save()
        await send(ctx, f"✅ Secondary hub is now {channel.mention}.")

    @vm_hub2.command(name="create")
    @staff()
    async def vm_hub2_create(self, ctx, *, name: str = "Join to Create 2"):
        c = conf(ctx.guild.id)
        cats = c["categories"]
        cat = ctx.guild.get_channel(cats[1]["id"]) if len(cats) > 1 and cats[1].get("id") else None
        ch = await ctx.guild.create_voice_channel(name[:100], category=cat if isinstance(cat, discord.CategoryChannel) else None)
        c["hub2"] = ch.id
        save()
        await send(ctx, f"✅ Created secondary hub {ch.mention}.")

    @vm_hub2.command(name="remove")
    @staff()
    async def vm_hub2_remove(self, ctx):
        c = conf(ctx.guild.id)
        if not c["hub2"]:
            return await send(ctx, "No secondary hub is set.")
        c["hub2"] = None
        save()
        await send(ctx, "🗑️ Secondary hub removed (the channel itself was left in place).")

    # ---- categories (server owner / bot owner) -----------------------------
    @vm.group(name="category", invoke_without_command=True)
    @owner_check()
    async def vm_category(self, ctx):
        p = ctx.clean_prefix + "vm category"
        await send(ctx, f"`{p} add [name]` · `{p} remove <slot>` · `{p} set <slot> <categoryID>` · "
                        f"`{p} list` · `{p} prefix <slot> <text>` · `{p} sequential <slot> <on/off>`")

    def _slot(self, c, slot: int):
        if slot < 1 or slot > len(c["categories"]):
            raise commands.BadArgument("No such slot.")
        return c["categories"][slot - 1]

    @vm_category.command(name="add")
    @owner_check()
    async def vm_category_add(self, ctx, *, name: str = None):
        c = conf(ctx.guild.id)
        if len(c["categories"]) >= MAX_CATEGORIES:
            return await send(ctx, f"You can have at most {MAX_CATEGORIES} categories.")
        n = len(c["categories"]) + 1
        cat = await ctx.guild.create_category((name or f"VoiceMaster {n}")[:100], reason="VoiceMaster category")
        c["categories"].append({"id": cat.id, "prefix": "", "sequential": False})
        save()
        await send(ctx, f"✅ Added category **{cat.name}** as slot {n}.")

    @vm_category.command(name="remove")
    @owner_check()
    async def vm_category_remove(self, ctx, slot: int):
        c = conf(ctx.guild.id)
        removed = self._slot(c, slot)
        c["categories"].pop(slot - 1)
        save()
        await send(ctx, f"🗑️ Removed slot {slot} (<#{removed['id']}>). The Discord category was left in place.")

    @vm_category.command(name="set")
    @owner_check()
    async def vm_category_set(self, ctx, slot: int, category: discord.CategoryChannel):
        c = conf(ctx.guild.id)
        if slot == len(c["categories"]) + 1 and slot <= MAX_CATEGORIES:
            c["categories"].append({"id": category.id, "prefix": "", "sequential": False})
        else:
            self._slot(c, slot)["id"] = category.id
        save()
        await send(ctx, f"✅ Slot {slot} is now **{category.name}**.")

    @vm_category.command(name="list")
    @owner_check()
    async def vm_category_list(self, ctx):
        c = conf(ctx.guild.id)
        if not c["categories"]:
            return await send(ctx, "No categories configured. Use `vm setup` or `vm category add`.")
        lines = [f"`{i}.` <#{s['id']}> · prefix: `{s.get('prefix') or '-'}` · "
                 f"numbered: {'on' if s.get('sequential') else 'off'}"
                 for i, s in enumerate(c["categories"], 1)]
        await send(ctx, embed=discord.Embed(title="VoiceMaster categories", description="\n".join(lines)))

    @vm_category.command(name="prefix")
    @owner_check()
    async def vm_category_prefix(self, ctx, slot: int, *, text: str):
        c = conf(ctx.guild.id)
        self._slot(c, slot)["prefix"] = "" if text.lower() in ("none", "off", "clear") else text[:20]
        save()
        await send(ctx, f"✅ Slot {slot} prefix is now `{c['categories'][slot - 1]['prefix'] or '-'}`.")

    @vm_category.command(name="sequential")
    @owner_check()
    async def vm_category_sequential(self, ctx, slot: int, state: str):
        c = conf(ctx.guild.id)
        on = parse_on(state)
        self._slot(c, slot)["sequential"] = on
        save()
        await send(ctx, f"🔢 Numbered names for slot {slot}: **{'on' if on else 'off'}**.")

    # ---- default name -----------------------------------------------------
    @vm.group(name="default", invoke_without_command=True)
    @staff()
    async def vm_default(self, ctx):
        await send(ctx, f"Usage: `{ctx.clean_prefix}vm default name [template]`")

    @vm_default.command(name="name")
    @staff()
    async def vm_default_name(self, ctx, *, template: str = None):
        c = conf(ctx.guild.id)
        if not template:
            c["default_name"] = DEFAULT_NAME
            save()
            return await send(ctx, f"♻️ Template reset to `{DEFAULT_NAME}`.")
        c["default_name"] = template[:90]
        save()
        await send(ctx, f"✅ New voice channels will be named `{c['default_name']}` "
                        f"(`{{user}}` = display name, `{{username}}` = account name).")

    # ---- random hub -------------------------------------------------------
    @vm.group(name="randomhub", invoke_without_command=True)
    @staff()
    async def vm_randomhub(self, ctx):
        p = ctx.clean_prefix + "vm randomhub"
        await send(ctx, f"`{p} set <channelID>` · `{p} category add|remove <categoryID>`")

    @vm_randomhub.command(name="set")
    @staff()
    async def vm_randomhub_set(self, ctx, channel: discord.VoiceChannel):
        conf(ctx.guild.id)["randomhub"] = channel.id
        save()
        await send(ctx, f"🎲 Random hub is now {channel.mention}.")

    @vm_randomhub.group(name="category", invoke_without_command=True)
    @staff()
    async def vm_randomhub_category(self, ctx):
        c = conf(ctx.guild.id)
        await send(ctx, "**Allowed categories**\n" + ("\n".join(f"<#{i}>" for i in c["randomcats"]) or "None")
                   + f"\nUse `{ctx.clean_prefix}vm randomhub category add|remove <categoryID>`.")

    @vm_randomhub_category.command(name="add")
    @staff()
    async def vm_randomhub_category_add(self, ctx, category: discord.CategoryChannel):
        c = conf(ctx.guild.id)
        if category.id not in c["randomcats"]:
            c["randomcats"].append(category.id)
        save()
        await send(ctx, f"✅ **{category.name}** is now allowed for the random hub.")

    @vm_randomhub_category.command(name="remove")
    @staff()
    async def vm_randomhub_category_remove(self, ctx, category: discord.CategoryChannel):
        c = conf(ctx.guild.id)
        if category.id in c["randomcats"]:
            c["randomcats"].remove(category.id)
        save()
        await send(ctx, f"🗑️ **{category.name}** removed from the random hub.")

    # ---- auto-unmute ------------------------------------------------------
    @vm.group(name="autounmute", invoke_without_command=True)
    @staff()
    async def vm_autounmute(self, ctx):
        await send(ctx, f"Usage: `{ctx.clean_prefix}vm autounmute set <channelID>`")

    @vm_autounmute.command(name="set")
    @staff()
    async def vm_autounmute_set(self, ctx, channel: discord.VoiceChannel):
        conf(ctx.guild.id)["autounmute"][0] = channel.id
        save()
        await send(ctx, f"🔊 Auto-unmute channel 1 is now {channel.mention}.")

    @vm.group(name="autounmute2", invoke_without_command=True)
    @staff()
    async def vm_autounmute2(self, ctx):
        await send(ctx, f"Usage: `{ctx.clean_prefix}vm autounmute2 set <channelID>`")

    @vm_autounmute2.command(name="set")
    @staff()
    async def vm_autounmute2_set(self, ctx, channel: discord.VoiceChannel):
        conf(ctx.guild.id)["autounmute"][1] = channel.id
        save()
        await send(ctx, f"🔊 Auto-unmute channel 2 is now {channel.mention}.")


async def setup(bot):
    """Registers after the bot is ready (every other cog has loaded), and skips any command
    name or alias another cog already owns instead of failing."""
    cog = VoiceMaster(bot)

    async def register():
        try:
            await bot.wait_until_ready()
            taken = bot.all_commands
            clash = [c.name for c in cog.get_commands() if c.name in taken]
            if clash:
                print(f"[voicemaster] skipped (name already used by another cog): {', '.join(clash)}")
                cog.__cog_commands__ = tuple(c for c in cog.__cog_commands__ if c.name not in taken)
            await bot.add_cog(cog)
            print("[voicemaster] commands registered")
        except Exception:
            traceback.print_exc()

    bot._voicemaster_register_task = asyncio.create_task(register())
