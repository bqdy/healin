"""
VoiceMaster cog for discord.py 2.4+   ->   save as  cogs/voicemaster.py
(replace your current cogs/voicemaster.py with this one)

Needs:   pip install -U discord.py        (2.6+ for the new panel look; older versions get an embed)
Intents: Server Members + Voice States (+ Message Content for prefix commands)
Data:    voicemaster_data.json (created next to the bot)

How it works
- Joining a hub (primary / secondary) creates a personal voice channel and moves you in.
  The channel is deleted when it empties.
- Hub 1 uses category slot 1, hub 2 uses slot 2 (falls back to slot 1, then the hub's own category).
- Random hub: joining it drops you into a random voice channel in the allowed categories.
- Auto-unmute channels: anyone who joins gets their server-mute removed.

Panel look
- A "VoiceMaster" container (welcome text, logo on the right, "Button Usage" list) with two rows of
  icon-only buttons underneath: Lock, Unlock, Ghost, Reveal, Claim / Manage, Rename, View, +, -.
- The white icons are bundled in this file and uploaded once as *application emojis* the first time the
  cog loads (needs discord.py 2.5+). If that fails it falls back to normal emoji.
- Logo (top right of the panel), first match wins:
    1. VM_LOGO_URL in your .env (a direct image link)
    2. a file called voicemaster_logo.png next to the bot (next to main.py)
    3. the bot's own avatar
"""
import asyncio
import base64
import json
import os
import pathlib
import random
import time
import traceback
from typing import Optional

import discord
from discord.ext import commands

DATA_FILE = "voicemaster_data.json"
LOGO_FILE = "voicemaster_logo.png"
DEFAULT_NAME = "{user}'s VC"
MAX_CATEGORIES = 10

# --------------------------------------------------------------------------
# Panel icons (white, 80x80 PNG, base64) + normal-emoji fallbacks
# --------------------------------------------------------------------------
ICON_B64 = {
    "lock": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAF0klEQVR42u1cTYgcRRT+XvfMZjGGmCX+xR9MjKJu1sMScwiCSkQM"
        "giBqFEEkBNmLB0E8eBG8RD2IV7O4oqCiJwVzi8kegogJGlETAko8JCFZF9mFGMjuTPfnYV6ZSqXnt6d3qsf6YJjZmdqu6q+/V/Xe"
        "q9cNBAQEBAQEBASUEuLTYEgKgKjFuAggFREGAq8kLgYAEUk6bG9IHjiZ4gFx/5FAcgzAOIAtADYDGNOm/wD4A8CvAE6IyHn7GJ0S"
        "PzQgKUZ1+vdjJD8jOcf2WCD5Ncld5hgkIzX//wV5kfX5EZKzDkEJyVqTV+K0/ZnkM1nHHmrySFZIvueQVieZdqDAVNvWre8+J3md"
        "PZ8OM3k3kjzkENcrjFpJ8jjJLUNJopmjSF5P8hc94eU2xNQt061nmK8NQ+IcyfGhItEsGPqabUNeO6LSFoo1JP5OcmylFpbKCnAY"
        "iUhC8l0ADwOoAahmOMgEYFTzJ4DjAE7p97cBuFdfsX7numEVAHV1f2ZE5ClVYVJm9cWqwG2WStIMVRnsJ7mT5GiTYz1I8hPH1F0Y"
        "db9gFqxhWDgOWSbqkpeSvETy5QzCKvqKnd+esHzGJGP+TEmeIjmqF1BKqT59397kRM18tkRyp+XexFknbM2lVf17guRfepwkYy4l"
        "yZdKq0IzaJIzziTvnuSUthvp4tgj+r4jwyek5VMeLqWDbRREcjXJsxkKNCc826tCLCVOZ1wgM69eIrmpdCRa5juZsVDYBD6pptkL"
        "gWaBus9anNKMPp4r0oyLuipmDhvXd9uVSNUVmQNwUDMxXbsamoERETkB4CeT3nJcIwCYKNRHK1iMdzdJigLAbyJykWSUI6dnxv+j"
        "c2z7It6V8VtpCFzbgsBzfRzD2S7HUBoCkxbmfYdl0nlxZ5djKA2B0uNvvvaz4gQOPQKBgcBAYCAwEBjQM/oeH2oiISbJdu6Fxsx5"
        "Uu/d9BOT7HslQ6XPxEUaoy7pd0st/qWubfM4ukkH/dTsfpRMikjqDYEaz6YAEpJr0CjNWGvFoZLh2K7XRKrkiFPNnsfGFv3cRPJx"
        "ABfRKAv52xnzYGGl7cdIvk/yDP3FPMmPSW601FhYCNSx8khuBvANgHushEGKDkrV+rgYtuvHbjMP4GkROZy3OElyznkCYB2AIwA2"
        "AVhGY8vS100corH1WUWj4msbgJNo5BXTXq9cz1ddO31byasBGPGYPCOYqpJ4LYB9AzFhy3TXo7H5vVqPVabtQ2PWkyJyrFdTjnIS"
        "/wCANWoaZdt7NSb7UB4x5SXwZmtuKSs2DDKUG4bS2lznkNeRloJNzBQdRSh+B9GPWLiPqogzCPVuofKRQFPmdgbAUXWPJtEoW4Nv"
        "C1bFM+KMub4OYJ+IXFC3aRWAZ9Vvu8YnEn0jMAIwJSLTTqy6LCKfkjwPYD8uF2gOnERfEqqJjuWgiEyTrJIUEUmMc0tylYh8C2BG"
        "23rhAUQeqQ8AvtDsDu3Ep36u629f+jR2Xwg0pniuhVNukqDzgcDmCmxVohGpAm93QrFAoKXAF60bD+1bwsx2QQpgdyDwasRKyFaS"
        "e0WkbufnRIQiskxyD4Bd2rYSCLx6LAmAN0h+QPIWvVkmIrmO5FsAPvTFffGRQKPEZQBTAJ4XkVSVuB3Am0qwBAI7U2LNiYO9zPz4"
        "WpkQO2OTjORCiIXboKahnDhqDAR2iFutMG6D4y8ODYEsyHwJ4FWSiwAWAOzFlXdzFuHED4TAIk7IrLCjAN5Zofl2YAQuFuiX2Tfg"
        "xAX2sTCIVdhECUfRqMSKCjBn0QtcKYg8409+l8eUeyJQN9VjETkN4IAOpI7ywOy5nATwvcbaK17aQe34NTTqTKolITGxFP2KiNQ0"
        "UcFeZZyHQVPisQPAV7hcpeDrfrE9l+4RkY8G/ugo69bW+0keaPPUDR/wA8lH7bH3w2XITaLl9E4A2ArgBs/UtwjgmIgcccfsBcr0"
        "ALB+PpRHiiDS4ySFdw9wDAgICAgICAgYEP4FqH51vTnOuN0AAAAASUVORK5CYII="
    ),
    "unlock": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAF2ElEQVR42u2cT6hUVRzHP7+Z9zJKE0sENRPNKKMSxSykaFEtomVZ"
        "QbQICTctgmhhQX821q4IgpQKiRa1isidtpIwtRCM6oGUgZKFpcarHr65M98W8zu903XeqDNzZ87Muz+43Hvn3rn3nO/5/s7vd37n"
        "dy4kLJJMkqVcRksJLKDiZRLQMDNF16uzXZvT4iyrdvC/qqTKnGVgYJyZ1f18HrAZuBtYB6wCrvHbp4DjwFHgMLDfzCYjZs4tRsbM"
        "kbRc0quSjunS5YSktyXd3OqZow5e1fdjkl6U9HsETF1SzbfMz8OW+e/16P4pSW9KWhg/ey6At1rS/giIPDAXk4b/J8iEpLtCw4w6"
        "ePdK+s0rPu1gdCoxkFOSnhxJECPwNkmajFjXDpSgxll0PhtLs6ghtowUiJIqvi3xzj9UuBVw2SWwLpuFtaGv/EfSun4ZFusH+8ys"
        "LmkP8DCQAXl2NNyJBjgD7AO+Bn50x3kFsB54EFje4j9B6kAV+B7YCJwHNLQuTlAjSY9HfV4r5kjS326Vl7Z53kJJz0j6pQ2Twzte"
        "GXpV9lHGmFvJRos+LJwfk7Q+N8oY8/1/x9H1FZEVz1p0BXVJf0paEjntQ8u+R2epaN0re0LSSr93vF1lvUHG/Xi+pIOzPDsYqJeG"
        "loWR5f2shd8WO833BPA6aJyVks5EjZE3NN85g23oVNf317kqKVfBAOaHlwte9I7AxO2zuEUN3wq1yEWZ+fDcWz0g0MhZ/Ipb13e8"
        "Yo0O3lH3htoNTLplV84im1vjwupaFIABrLWRy5F3WX4Gvgnxvct+gVmjubNTwFf+jJrv421tkdpWtKO5psVvAayjZpZ5SKtTP63i"
        "LPzB63KF7+Pj24LWF1HBoq3TvDbXzveiuzUzSToCfJtz0oNTfbxIAIt2Yd5q0cEHl+PAKMTxBln4+iiM9edGFLcEsASwBLCUEsAS"
        "wBLAEsBSSgBLAEsASwBLmZGeh7M8PleVJNrPO4e8wEof5yx6ngY31mPgQr7fef+tXcwv83v7GpXxRpNHtNMAUFLFC1SXtIBmFHgh"
        "cFNgW8w83y+W9BAzabuFYeb7SWDCzP7IlXmwEgKikq71XL2TSldOS9otaVXExq7EesE8SWuAz4FbolYPk0fWhhn9ZEBcltPAI2a2"
        "P+Tu9B1A7/MMWAQcAlYD08A4CWX/t2i0zMv4F7AJmKA5u9fotFU6blF/6esOXo3mTFjKWQDm4GXAfGDnQFQ4Ut3FwE/A1f6sYUqh"
        "CF3MBjM70qkqV7oE/k5ggavGsGVABZW9rxsydQvg0pyrMIyybJBDuVGYmuyqDt060lawism3CsXn8aQxFu4hK6otAE3OUKUIoBy8"
        "kzTXxdWADcwkKiVlsMYSAy6o6wvAzmhB4Txgi/ttV6UEYmoAVoBtZrYrN1adNrOPJP0K7HFnmBRATCWgWveyfGFmu0KyuZnV4+Ww"
        "ZrYPeN/vTcIDqCTEPoCPPbrzv8Uxfpz5tU9SKnsqAAZVPNXGKQ9B0NMlgLMz8MZ2ZXUG3pAbipUARgx8KqhublV7mC5oAE+XAF4o"
        "VQdko6QdZpbF8Tkzk5lNS9oKPOb3jpUAXliWOrBd0rv+LYWwVHaRpNeA91JxX1IEMDBxGtgGPGFmDWfiZuBlZhbPlABeAhNruXFw"
        "kpGfVDMTqrmyWYvgQjkWvojUos891VItZMoAXh8N45bl/MWRAVAFqa+A5ySdA84CO5gJcxXlxA8EwCIqFCzslcAbfepvBwbguQL9"
        "MkWWt1rgO84OwgqHUcJhmplYlQLU2byBxwoCL/iTX3ajyh0B6JPqVTM7Aez1gmQMj4Q5lwnggI+1+57aIX/x8zTzTMaHBMR6xOhn"
        "zaxGF4u+e5WddT/wKTNZCqnOF8d96VYz+6Db7Kzue+GZz5vcIWnvZX7GbhByUNIDcdl74TJ0DWLk9N5O80sZSxJj3zngiJkdypc5"
        "CfGw01AkGPXyS5dWBJAJBynKTyiXUkoppZRSSimlNOVfZJZQpsicKW8AAAAASUVORK5CYII="
    ),
    "ghost": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAHf0lEQVR42u2bW4hdVxnH/+vMmYlpExurvSQZM0m1GqNYRaVqbVpJ"
        "fUixFOuDihQvUCl4efL2IPgQfahgH3wQq76IIOIFqgURtbViLRVBa7UZMcZbtNVqU0kvM+bMPj8f+i34slj7XPbe52So64PD2Xtm"
        "77X2+u3vW+u7rCMVKVKkSJEiRYoUKVKkyLwltLkZ6MXDEAIFZzN48TwUKpPD69v3QeAbwJYc1CKj4b0WOMnT8kNga4E4odkavP8Y"
        "vHX7/lGBOAYeEIA3Ao8atMq+TxeI4wEuGMDbE82jQJwMYDAtPNfmPIBBAnFQII6BaN9bDZLXvKKJUy4kHmLRxLMN0aaIOE0s1Hx6"
        "7rrwTIQ4V3N2sPv26c0bbOtYOIQwNDh3SDokaUNS310Wz++UdF0IYS3elzjn2yUtSNoiaWdNl49IWpe0HkI4Nebl9iQhaTjLOD10"
        "oQUZiANJi+6yeH4GRBtgMHjflnSlAXp2TXfr9kKeknRS0kOS/inpuKSjko5JOh5CeKwGaLUpkx5t5kS3su8Dfu9Mf5j5TCL/An4M"
        "fBa4Hrgw488ubJo51DnYbSDGe3cBR2vuJYFZARt23cCOc5BPAt8F3gss5579rIHLOdpNF5bYHrAbWHUQp9XAoQO7kfzvlGWPrvWL"
        "WTqWeUQkC+78BmCve6NtNHHBaeJqDZzKPoNE+6oayBFoCvNXwE0+FTdzbUze2kHgLnuYVWD3GIhNNPF+4ClgDfjvhBpYJVBzMP3f"
        "HwDe0lQbwzQmG0KogG2SbpV0U7LC/k7SNSGEv0eATV0cd+8WSRfY6juUdImkcyQtSVqWtEvSHkn7JK3Y8db00SVVtgp7H3Ro/4vA"
        "viPpAyGEvwH9EMLGLJKor3KTfOXMIprkb4GLx8yJU63Odv58YN8ETvUe4Crgo5Y1OpHRzo0Rf3sYeLMfc5fwDgNP1kConEmeAJZd"
        "2NXGnGOksR/4NXC3G+ACsBgjkJpn3wZcDdwCPJj0uVHzIgFu7gSim48OuzloIzOnRPk+cCNwvo9XO3Jxlp1G3Qacm2SIQhLapV5C"
        "38bxTbfYDJP5sHLn7SA6eJc7eGlnUX4AvGlWsbN7loudJv0U2D5q9YweQwoBeA3w9Rpt9ErxtkZujnub24FjmU7i8b+Bd2eC+zCD"
        "iMW7OA/YNV+bdIAOpnfBDteML2riKWCvn4qmnfeOZDSlcgvGAR8ezSHsy0F867RaYm3FMV7gnqPKPMO3pmrfzSnPAx5L5onorJ4A"
        "LrLrFueZCkvM+Rjwh6ZpMgexD/w8geid9pdP3Idr9J01qk2c75rA61gTdwN/Aa5uGpK5tl5oTrsPG2P/RyZeUBzA26yhQQLy3q7i"
        "x4408VLgqjbJWjfmryTg4pjvmngedIO6M2kkNvppa6zfEl7o0tlu6+vas9yY9Bct7o8O8hl99hqEeYNOMrkhxB1dWFJ2TdJ1Ftb1"
        "LcyLEs8PSboD2GoZ7a7rI4NpQ97eiL+dsFiRpJHXxYG3LI1eCqxYW6EG4iCBOMhB7CLLbG28PhNHS9LDkip7RiadD96XMacYsr2i"
        "qZfuTHa/xdV7ukiFtSxM9czreDSziAyBW6dZRHougF9LGqxcLm1LBxDvA467BESrVFjTbLod3z4iYLhiWl8wrnBfqNHCGPc+103C"
        "vWke3L4PuZzcrnlpol8Erb8vj4B399QvyKn1TivSVImXHht/EDiYvNHelBC/NC+IPgKx8wNWgMrFwzEp+8qm8XAc4PWug2EG4hD4"
        "PPCi9A1PsBMhbla6J5NPnJk5m2IcAR7PvJiha/PDrXxep+Y3O2h1GZknDeSra/ysfiZRGuef84CvWjt/BnZm0lmtNBFYAi4DPmVW"
        "xQjNA7ilq5xgCjGXjEzPfwJ8CNg/ypTss+hAvsNM+RjwMjeVtIlYoqbvcAmIOouK55/ptFrnIN7g9kUPEg0c1mR5fwl8zuC8OA5u"
        "TH9XAm9IIXRQvF8GfpNc67XuNPDBmdSMHcRL3AC8r5RqZK4wPgD+avd/EfgY8HbgCoO7Es03NZ+25uzu9XVnX+m7H7h8pnXiJBn5"
        "HvPhPLSNmjpursidK0euAU/YPPgna/+eGZVMY3HsEeAjwNJciuyJSewAPm6DTbUgV+iu25JRjYG72pWL4yCuAJ+ML6dtRNNWG7cB"
        "7zKfapgZyKidA3X7Xqqk2tdl8T7ksjFnY39MyBRsLgM+AfyiRrM2arZkjIIbtemo08S2c+JYX3Xu+2Uyb/YA8H7b0LNas7DktHCQ"
        "2fuy7iDu7qJ430labkb7Z3rp1ggz+RdIeqmkA5JeImmvpAslXWRbNiZ1WlclXSPpH5ZyCk03efqdspsCYA6mnv45bDViLj1f0nmS"
        "dtggV2qafEjSE7av5XgI4XEghBDoarvxppXczoGuJ+7NsPH9bIFNf97Qr/ksjMv4lN+xzE4TC8RizptfE5dypcsCcXJNvBd4zjQ1"
        "52e8upprk5ZMF3Vm3TnK6abl2v9nc44m/L263QdFRkOM8Jam3gdYIPIz23e9VFbgZhDPAZ5V4DWMgHLHRRqEkYVEkSJFihQpUqRI"
        "kSJzlv8BP2pMtpzHg+UAAAAASUVORK5CYII="
    ),
    "reveal": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAIDElEQVR42u2bXaxcVRXHf+vMtI2FSsUilrS0lKpQo3xUIXykgsZE"
        "HhSFB0yICcYQ+qA8qI++NTEpDyZ+hBjTxK9ExfqApg8NEEAUColaEYqmtQLeihSu1hQK9/bOzJ+HWbtst/vMzJmZeyG4/8nJzDlz"
        "9t5r//faa++11h4oKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCh468PeLIJIskimOrnkV/9FM/1fEegkWUJSz8x6Y9ZXpXUBWkpibQkI"
        "C50cSJSk04DTgDZwTs1rLwBzwJyZHR9CbOXa2ltMQm0RScPMuslvpwPnA+8BLgA2A2uB9cAZwNu97Mqa6ueADvAK8G/gOeAocBh4"
        "CjgEHDazYzWEdqdNpk2RuFZKmqTVwGXANuBS4KIB2pXaunHlnQWeBP4APATsM7MXUjmnpZk2JeJOCSNpDfBR4AbgGuDsTLFuRFJs"
        "w2yIXMosKHE9VabsMeC3wN3APWZ2pE72JSUwQ9zVwC3Ap4Czold7ftV1cNoaqLCY+Put6LeXgL3AD4C9wSZLaqXmZtEIDDYuNCjp"
        "RuB2n6axhlFDmDLaE95tso3pJf2wmrKK3o3J/CNwJ/AjM5t3O7m4K7g3Er5vk/SgXkdP0oJ/Knne8d+6Gg1zkk56mQX/Pj9i2a6X"
        "6WTa62We/0nSZzI2croaGNTcV9JvALcm2tbKTNsq0qyAk8CMX08Dz/p1FHjZV9nDwDyw4GXawApgg6/Qy4F1viCdC5znv50LvC2j"
        "gd2MLGGaB7l/CXzRzI5IaptZZ2oEhgolbQV+DFyYEaCOzBd9RXzUr4PAjJktDGhvNfA+J8aAI8BBMzs6ZHas8zKXA1cCW/1ZHWnp"
        "s+eBW81sTxMSh5Lnn9dJOuFqv5BMjU4ydZ+W9B0vc2ZdhyW1JC2TtCwsRJJ+Luk/mal5QtJeSZ8OM8LLtmPTku47JV0jaaekAxmZ"
        "Y8R92h73feK9nRMxn2m4l9zfI+kmn+YpWW3vdBX8XkkW7iXtSAahG9nA1Jbtcs+FTF2t0FaqCN6P3VE7vaTubnQ/GYkReZdH5KWN"
        "xcR9PCNwKwoS/M9qHn6XdFdCWi+jgWGwwoA9ImlVPCAD2mgnzz8s6Wc12hgrxU3jLCzxaK6SdCjTSPg+K+mWzLS0BgO0w+uaryEu"
        "hzCgd43awYjMVvTsupr+BU08Lmlj4GMcuxc6dzKjeU9K2hLZo9YY2n3ZgO3PMASZPttUS4JJ8e9nSbovM6uCTfxFo/ojm7JG0rHE"
        "TnT9fkbS2f7esgnMw+6aRWkUhIXr8dS2jqEobUmPJST2Ik38YLoPHqXSm2tUW8HejUleFY38cRe0p/EQBvTSsWzVfw/mZkmvJPKE"
        "gd1Rt6AMYnRb4jqFzeg+M7vXN9YLE7iP7wdWRT7rOAg+9tZxXVN3Dtpm9ldgt9fRTeq7yrW7NwqB4aXNiW8ZiHwgiixP4n9vyPi0"
        "42LTlOKY99XIuhFomVkvNRPVGF7KAtNBxfQwrboWmnps1YBnM5l4G8AVHrEYN2oRyv1jSjFJuayTBUb7fbqyRtZ/Al1JVRqtGTRy"
        "Dyeda/l0u1bSxcF2TEDgAQ/RVxMMRgiX7R8SRxy2qPU8EHxz4isHRXnUiatGrRBJ6yW9mqxKYRXeL2nFuK5O1Ma9GXewyQrclXRY"
        "0grf7DbdxrSibdvdAxyGq5ruBcPS/t3MPi2QuFfSO6N9VNVEcP/8RGaj3nQj/aWmA+lktyMSdw0g78GR94DJTr2StFbSi4mTHVd+"
        "QNK2ZESrhiR+P3HPmpD3m4ZtVjHRkrZIeqDGHw5B2UvG9YdDB6+vCVl1osbulPTedIQHdSzyTVdK2hdpenfItA3kPSNp3TA/NYoE"
        "xdH0te6mvpSZYb2oja+Ou0FPvZLtEWl1EZkTTuSHcvWETsR2KrI/Z0j6SUYD4isevPslbcikGdKQliVyXCjp6z6rNEDzJGnntGKC"
        "KYm5YGR6/2tJt0u6YIhWtD0oGoj8nKTfDdDAv0j6cjQ7lseDU9PWeZK+IGlPYiYWMjMq3N8xquY1DenfAOwC3uG5izjPELJfcaMd"
        "4AnPy+7z0P7fzezVIe2FJPzmaE/6hJk9PKTccs+TXAxcAVwNXJLkSTouoyU5k7ZvpL9iZt8eNWfcJKkUSNwEfA/4WI1AceI8Vf+O"
        "b0oPAn/z5NGzTtCs7wvnzez5GhnW8Pr5mXf7td6J3kT/uMg5noBiSJo1Jg7gceA2M3usSZ648b4pygd/Hvha5IfmEkqKNDNNcud8"
        "8JNez2xm0ypgtWfk2pnBITOAuWR+yBiG8v8CdgLfNLOTTZPs4yTWTyWgPXu2HbjNHe5Y06pMojuXVLeoo00jMbl6coGOXmReLMoW"
        "/hD4lpnNhL41PWo30dGOSBtPB26kf7TjI0m9nSGdI+OGjXK0w0YkN9XU33tq9qfh0JEvlGOd3JrIkffVsxXnTyVdBHwSuJ7+iayq"
        "ZnqRIXVUeZTRaAaYiQPAHuBXZvZIstd9Yw4XZYisUmE8Z3Kta+UH3Ni3RyCmOyR4MEzuZ+gfcXsIuB/YH0/NSTRuUQjM2Mgqzer7"
        "aJ/vkegt9E83bATeRf8I3Moh5KZEv+x2bNZX8qeAP/vnITOby+xnp35idbGP+J46alu3sjmxZ9I/oboaWBZFq1M8R/906glfPY/V"
        "pRW83hCGX7RTV0t2yDxzwHwq2pCcw4YlPmj+hv/NoebvDcNW6lMLx5vhrw4FBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQVvdbwGPCLQ"
        "WWNph6sAAAAASUVORK5CYII="
    ),
    "claim": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAESUlEQVR42u2cMYgcVRjH/9/MJXqXCMEEhBiFNKIiiZAYsFK4SCqJ"
        "llcJB8FCkkbLkxiuCIhNIIVNtIrYiEpCqkAgxEKIIZJem2CTIAElOXI780+R7+HHuHv3Zue92bu97w/LLMfum3m/+c03b97MHuDx"
        "eDwej8fj8Xg8Ho/HMy0hKSTFSUxxZKOap293AtgO4G8AEBH6LosDOKPLL0h+r+9LJxNf9wqScyT/IlmRfDn83QmtD7DU5RL/y0W3"
        "MA5eoabtJvmAZK0G1iQPOMR4+75U81ZJDvT9z5sWYB+1x9i3n+SKMY8G4rv6mXLT9Tn3gNbY97Wxjw2A1/qwMBm8AI3kYWtJDnhq"
        "1htD7GtCfD8nRLMjD4XhVIrx2I8kz4e/pYZoNvqHIfY1Af6ea0hDcpsuT5G81Xk9BuAF3fjTqSEaeG8ppIqjEyAupLbQ9PUjXccv"
        "nQ9n0+g3pmPLdm8lBHitAWlYwqH9J8nZVCXFmLeo66lJXk8J8Ftt+JEul1JANPDeiYDXtPBju40J4C1ou491eSMHwMemPi12gWgu"
        "2QqSv7YAGCy8S3JXFwsNvHmVo2oLsC1dAVACqABcILkoIqtjQixFpAbwIYAj2mZMTSv0sy8C+ETbKMeRQ7d9HsAlAM+OyaSVgaum"
        "Rgy6mKjmlCRvN9pjpIUVyXskn2878Wr6NU/yoWnTHgVZDLQmFuOaqHu/BrAI4CCAthYV+p09AJZ0nrCIPWxFZGDMm9W20l9trWEg"
        "xzXR1L5nSP5hJgzaJnzvX5J7Y8Zs65jHPg3sYmKh9p0EsL/D3hf97g4Ay2qhbAjzWhi4lokzI+wTPXve1+/V7JZK1/3aKAsjzZuI"
        "gWuZOBhiYqmmnASwWz/fdSAc6ufnwyzUetuveWMYOMzEDxpjrTDm20fynxETBl0srEm+bae7zPa/GWHeRA20JobadJHkvNbEGVP7"
        "PsPTu2010t0VDOadDnfujHmvAris5lWp+5xD49DmHIBLCnHwtE98BcCJMYYt6w7KFc4xku8BoIF3VQfdVeJ1ZgNox2mzCvGoiFQA"
        "zijYlPY1c1ZEat1ZWeEhcyG1EH8ieQrAcT3ccnSm1LYPkfwUwJXc8ABgBnlTaKd2ADiH/BFd31emNpa5O9hXp2r0k3ASy1kmejOw"
        "eXbuK8XUrWha4wAdoAN0gA7Q4wAdoAN0gB4H6AAdoAP0tEqb6Sya1zSnVR9jAYb5vAIb9Pd1iY/K6PnLWIAVgIG+pt3AcA9lEGvW"
        "aJdJERGSfAHAc1usvK2IyF2v8pkTa+DrAPair2dKJn8SEQAPRORmYDAuwPB4xHcAFraYXL+JyGGS4ZGUTieRFbVvgP7u5E36JPIw"
        "9TCmMK9pP4Sj++lXIj1didSqdooHIjfDIRz6nAzgnNaFrfBr8dDHnSkAhtP3HQAvIfOTThskYah2xwvUpAfSdkC9BWrf/7rt/+jH"
        "4/F4PB7PFOcJo2MSwxQj7psAAAAASUVORK5CYII="
    ),
    "manage": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAIUElEQVR42u2ca4xdVRXHf+vO7czYFkFRqBTFMaDGEkwDFWkQDKjR"
        "aIpifSRGSDSoEUKCfFM/1VRDjH6pibFpfKQmpQLBRxOoqCEgVMWg0EGtREpD22ih0g60du7r74eztrPncO5r5r4G90pO9txz9tn7"
        "nHX+e733QKJEiRIlSpQoUaL/R7JBTCLJfC6ZmRLbO2SapDFJpYJrZWdqQmAT5pXMrBH9PgNYAVTN7Eh0fszM6glu85k35u24pBsk"
        "/UbSEUknJR2X9CdJmySdE5iduBYhz9uLnVGt6FlJ18VMT8jL2kslvehMqvpRybXViJG3LmUmWgeMMaDVyzWAoFlPA/4MTAE1v8+a"
        "3BPaMrDezPY4Extt5hsk1QdiNUgqe/uVCHkN//t5SbdJulbSlyRN+/mGpJr//aBr7dIIrixbEAIlmZnJUbERWJXv4vfvAR4BJoC/"
        "AG8E6o6iI8B7zGw6Gnc58AvgKu9nQAm42MwelbQa+HiE0mHRceAuM3sh8KJrheDHHW2UwfXef62jqhHJuC/6tQm3Ccf995tdHsZ9"
        "b/FrUxodekTSCl8dhWArN1MIZlaX9HZHX7WJHCsBB/z3WTm5BvArX5ZVtwvr/jX/LmkfcKGjsAy8zu85ChwEzo5QPhT5B1wCfMDM"
        "7nQxVeuIgZFSOOY3LWvSx6JrNf9tEXNPixngX7Hk7cpIjCh6uDFgssmcg6Qw/z9zPJlHhULbzBruTRwAbgSeAyqOxJofs96e57ft"
        "9z4l/3oAn3VPQ/4Fg+fxQZeVgdEG7PN7Vjlza7n5BnlUgBeAb5jZb50X9a7NmEiRvBo4vUm3GeB5/0IPAuudMQGNtwJbzKzmY14N"
        "7ABeE33VWeACMzskaUW0fIdJJ83sXwtSIEUGcodG9DUufCuRqSJJf5W0Q9JDOSEd+n13FI3pTswq63Aga9FXjtKSL/07XPFUXI6o"
        "QFQokq0HgbXAv+OxRoF/Aw29RWbPKz2AoMionpV0ytvYyD4saV0KKuSsdo/3fc29kCJqSNop6dylzjzrBxMD9CW9HtgAvBN4lSuL"
        "x4BdZvZoUewwEXPR6A6W/JKPSlufGVlyBaLcnI2EukT9R+AQbLaA9kbkFsoRn7KBvTD2EwILzCY3vt/gccQr3J+uu399D3C3mVVS"
        "FvClmj7YnV+VdKxFXG9a0vtG0V0cqpnkBvvPcl5PJfJ6KrkE1k29ZmKnvnBpRJa73N8OAd9vA7e08btD0iukDt7lIaowRrN3U09M"
        "rVFzs6LIz9pcAiv413slbZG0XdJzBQmsxxy5pU6Q3q5PuQO3rCFpCjiT4YXYw7zHgaf83M256yVgE7ApKApPUN0OXO7314GLyBJd"
        "90qaBNbk3inM9aKZ/W3RyJP0ZZcpo0Df8WdaLunpXEzxnshFLEta5r/PkTTjKAyJrC1+bYWkZ1oEPLa2S7eWmjHPkXc+sJksZRlk"
        "yTCOqrdP+iOexVwSK6Bnu7/omJnVzKwqaZmZHQbuZy5XY8Cb3Pw5QZaKCPHJ/Lw3AFcHudv1EnbG4dAfpiVfj5YgkUKI6VS0BMn9"
        "faoFcGo+br1A+YwDy1sp3HZJpSeAre4SlYd4THr7Fn/Eo37ETPqoa00LS9jMapJWAu+OZJvIouBIegXwVh97IjfnOHAfcK8rk3q3"
        "CJQz8/OSbme4edow70H/sDOSfgd8JFqan5T0SzP7USSKxoFtwGuZq5YwZ0wA0M05PoS5ZoDdbuosPLE0ajG7yIy5qqAOR5J+LulG"
        "904e93N1N2Makg64EurJe1kXDz0KjGzkDOmd7v8GQ7ronYLiCEmsj3mlQRij2bu9fKM4UQLr9KiQsx65cvERu3LfTP5wTrR4FvCH"
        "bezHo5K+EJjXS7G05MNZUQLrcuB64DKyqoeGey27ge971UNKYDWJzJRy51Z6iUgKqHarneOAaVSe3LdSXXs5IjJyCPquQW1EXrpU"
        "FMdL8qpDc2Sh10eBbIjMG4vidheSJYMu8Mv/AB4ws8fzfRPNd8fWSPqpG8FF8bhdXqedjN8C5n3CA535Mrh8CdwJSZ8eVSZaFy++"
        "qOUe9py4/3kp2f6S4KMWKhHmV/xfaWYPRGP0Xfz0RIv38qu7UhiX9ESTSMpeT/qoIBn0pKTJVns2+rVaWlEnSaUg6CcXifSqBzg/"
        "DLyNLD4XUorTwOfMbI/PtQ74Hlnpb0Dp+R5J2R7lPPpp51U6iQW22uoV8iLvB77u/qV1qblDEPOPwLU+3k/Iaqhr/gGPAxeZ2TPB"
        "ZPF+q4C9ZNnA0HeXmW1wBO4k2xEQ5ugZ8Pw4AXzLzLZ17UOHZSLp7DYlE53SjigSstfPzXq7za+NR/OHLWFbcn33Rdd+MKBMYEsr"
        "oNkSLjl8zyXbHzLLSwslO6GAnJkI8RO5Pvujba7/UyB+bn+u70SEthmyQGqN9smxBYkcsoTSGrKy5M73ykUlD9OuLS9b4IMEVE1F"
        "mvVYrs8VZrbZlctY9AErkq7M9T3G3L69KR9/vE8yMGzBuG/BSSUzm5X0IeAmss2A3SaVQv9DksquRH4PrGMuGfReSRvN7M5Ydkra"
        "QLYlLITkBfzBxxgDHgYO0Z9ElxzhW83s2UXvVuqxAX2Jy5Zabnvsbf7vAt4habPLvUbOlFk/aIN6wRuuC2Jqi3qOkMDx9sfAp1yG"
        "tVuCoc9dZraxg2RQL2m0IkIheizpDNeooballquyqvq5UPfylKQzl0J0ZlCxPyStlrQ7ZzLUCwILv5Z0XnxvCihEjJB0ne/iPBkx"
        "7T+S9kj6TJR9G0nmDTMeOE+zOcpW+8/DZvZ03itK0GuinYs0XVQHPdJ5GxuxZW2R1k6IS5QoUaJEiRIlSjSy9F+QMK58VREmpgAA"
        "AABJRU5ErkJggg=="
    ),
    "rename": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAADiUlEQVR42u2au2sUURTGvzubiI9GrCzsRBGjjRhFEHxrCo1gGkHQ"
        "0tJGG4soFlaiYiniX6CCYC2WFjYWNjai+MLg+5lkd38W3sHLsLu5s9nNY+75mkmGzezsL993zzl3RzKZTCaTyWQyFQU4o9A9vCw8"
        "mrqDt9Igloc34I97gVfA0fC8KQ7ePuAH/zQZQBw0SnHwfnl400DTHw1iJLyfHl4jOBYhWpxncF4Ojw4QzYkzOI8IiJnBi4NXhDgF"
        "HEkWYmRsO0HMX7sBqCUV5y6dlyuPMMBFYFmx+U5lwtjThfNCeBeCa44AY5Wvzj5qDjjo17BmD+DtAn7786OVhghkHuA24L3/0PVZ"
        "wvsRuLj6LU4Q4Y3A2wiI7eDtLsBrJtMnBkVkKAJijPNIbmKJgBjrPJKdWAKIreLcznnfIyp38k6cLBHbMhCTWhPHS8TWIAYQh4Fz"
        "XcTW4hyOYr7p3g98mwW8JJ2YAYPAMuC5BzDF7JWWE/3Eshl4U2JiMSe2mFiGIicWgzjLicXivAAgJjmxmBPNiQbRIFqcDeKCLCyj"
        "xRHTnBgPse5BHvNTUd+cOG//HedcHRhwzj2TdEDSO0k1SY0eXL4m6YukT/l7qarqsRPzv/sIbA12htZ4JzqD2Dm6Obzh4Nq3gfs5"
        "zBSc2E1hqbeBd9Wf/xA8r+0sznHwrhW+o9lfeRd2AXEmeNPBN4Q3Kt0bdgExBl64Nr4AllY+xpEQY+GFX/Q3gS2Vbq4jC8tkSXjh"
        "uUvJxLiNE197EBMl4IUxfpJMhDtAfAxsLwEvjPBvYG1SMQ5AZYXflwTw/nhAnZQDPtPv+XhBQ/SjWQacbgOp3gZmXnge9LIfdIsQ"
        "Yn7PKyStl3RY0l5JOyQtCV7akITfMMn8z07SV0nrnHMTgHPOIZMErPOuvAd8bvOkbP6UxIlkY9wi0gPFqgqsBkaBW8DLFnG+mVw7"
        "UwJmrXB+ObATuAI89S3NL2BVki1N7Drpi02txflNwDiwuRftjEsBpi8irh870y41Z/rPnElqWAU2mUwmk8lkMvW9kfZjUXOO7y+T"
        "1LSGN2UH5puOwFlJY/q/QdnXqcsfH0kalzSpf8Ps4nJivpsBnGL+dNnfw4LcuxuIdOiIpGlJU5Lm6gHuhnf6IUnn52H97QnAPDJ3"
        "JR2fQ3ih7oQFZTGvgSf9GlibwzXwoaTri74S27Z37/rA+bg/2/issv4CI+FuKUe1gx4AAAAASUVORK5CYII="
    ),
    "info": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAALEUlEQVR42u1ca6xUVxX+9pmh1FoKhdJerGltVYJorg8CtVCM9RHU"
        "0lAfhCq0UaJtTEwI11T/SNSI/iBSMbFp1USrUbHBlLYgP9RUW4GmtEWKERKpIbRUKY+2lDd35nz+mLW4i83eZ86dOWfmcrk7OZmZ"
        "M+fsx7fXXmvttddawEgZKd0sbqh0hKQzfXKBvtFccM7xggZQAEukD3TO1Qf5fiLvE0DaLUBdl0BDCDCS4wH0ABgL4Crv79cAHAKw"
        "D8Br/vsG0NQ5lw4rAGVwzg6a5OUA3gfgRgDTAEwBMAnA5U2qOwxgP4BdALYCeArAVufcPlN3JTZJ5xWAAhyUIkhOADAXwKcFuCtj"
        "rwJIA31NMkDdAmAdgLXOub2W4jsBZOFLValAfk8jeT/JV3h2qZPsJ1mT7ymbl1Sercm7de//N0iuJnmznUidzPMBPAvcTJKPeAOs"
        "yZXmAMleacY7qanXlidIzrV9M9J+SFJdIt+vIfkLbzD9EQAsNdVyUKA+G6I+C6b97zGS7/VZy1ClurtJHvQGw8jSjVHUKZIvk9xr"
        "ruMZoMbAtFR5kuS3ta8kq0NCiJCsOudqooI8AGC+/FUD4HeyHhAGLwF4RoTATgB7jKS1guQKAJcBuFYk9gyR3u80z6QigCqBdvXe"
        "RgBfcs69oH3vJuWNks8bSO7KWKq+gPgPyVUkP0zyzW20fxHJ6SS/R/L5APX5S7tfvh8gOc+OoRvgVeVzniwPmg4ysoSfJLmA5CU+"
        "CyBZlc9ELuddev/Ms4E6PkFynZmskLCy/Vnis6BOg3e3Aa0WoDotz5K8xa+jXalogK16928k+ecMaqyb/i03/XGdXLZ3RZanpcQj"
        "JPsM4ElZqoTqnp5AWyTCKLY69N6KIgVLU2kry7YWUBfsbD9NcmpIUg8WkMECbhVnkpOMLupPdkrytLecq2WDN03UjDTQGZ3RB0he"
        "1GqHQmC3CGTVfF+WAaJO+udKAdHwmnEkdwf4igXvW75i3cr+meQYkrNEUl8RsBsOhhp18hdGQFRl/gjJyYUr26YDf4jwEx+8lhiy"
        "Ae8bojxrOUhypZXObfDuRREQlSCeI3lxYbzagPcVaeB0yeD9ICItSfIho+q0A+LCiM6qY1lZiHpjZvxqkocDs6YN/qwd3mEmaaaZ"
        "pLrHIlTXvLPNthTEeyKrSXXHGW2DaAb2YKCxutHxRrWjRxk15z6Pn4b2u39pl0cZENcE+Ll+3+Sb5VoFb7phsqknuY4VwXRNW+sz"
        "ANQJ21GEoVeusSRfNOYzH8TPt0zt3qBis7S0CLFvKPD+DABV53y8CClpxvepwPiUVe2Q/fbgBJepvDdjdv5ZxHbMa292Dh64uChd"
        "zUzcoxlE8plBt2cq/mmE96Uk5xS5ETdSeGVAP9OyVvhtUoSKoZNPcrKwo3rAEPHXQVG8dkyU5lcNBdhKnyrDsmtAXOadn7wuAmZU"
        "q3pgDur/lUcsqVl9U3OP11DfnRlkPb8tCZUPxPEkP0JyDslJre5EBkGF7w/onQrm93MvYzMjj3kMXSveI5q6K8v8U9ReuIVJe8Ij"
        "lDOSP7YLSvzl65yrkxyLxrmtM6ZwNa+vdc6dBFApy51C+nCWNcY5Vy/RfUN56mqFwuBDOTaYIu0nUQDN7w/IGURqzk30v4e9RlDC"
        "kqrKxKmTUdAKXWBR35o/AjgpZzk05ylVALND50hJ5JBplkd1qTz7shwAAed6DhRi9RFKq0WuekkUn5JMnHMvAXguMr6bQoTjM0Ua"
        "Cgzd3+KcO0GyUvRgBDyS/CiAT2LAc0vbTwBscs6t0WdLWMYE8HchIHpE1qsTnGcJ7fSYqAqSb5ZhcPQs3c1KXxkHQaYPt3mCRFW4"
        "wySv9DWBJKAeWNcy533uLJP/Afii1H0SjXNle52SZbW4JBaiY9qFgbNlmrFfhob32Fl8MAnwv4kCot7T5ZMC2F0ygNpmNXCNMv0o"
        "w0NV6/svgNe9e7ps3+LjFgJwghHf9r+aqXg4l2MA3oj8NxERtcUC2OMtEQXyIBoeomVTYFeKCLAEQL9QoR2nfl6dBSCa8BaWoboM"
        "RSAzxlnPAyAxUvLrPoF71RFYoqWaBaDldfY/5Y3j5TpnOzMciijJqZyX9ETGuT8PgPs9/UfLaADjLgAqe5NR43wBuy8PgIcAHDH3"
        "nNkLXztcKdCMyYZa6D3d9fzPF7SJJ32ARkDLAQ9UfWHyBQDg9QJYajYSAHDcAMigEBGLRD+Af3vAaeUzhrGkVmPp9Ige/CKAV/xd"
        "UMweuDUyOzcIk02HbLhA60Vtgjd5Y1Yg/yWG3kqWGqPIbvYq0a3d9QB6Q5bZYSKBJwL4YASbTSH2FQPwGdkPVrwNtQNw2zDkg3re"
        "MgfAGDNWGAPGkyH2lXjbGLXMHhAQ7bZGn/2skHF9GAFIWVULAsIzQSP0Yntoq5tk7E4e9aSQzsS7ANwspF8ZBss3EZ7+dgAfx9lx"
        "JgrWBudcv8SVsBmASllrRHRXA1aJrw+ViPEitrMylq/JZsFfvgDw65j2kUTMOhWJv10vL9WNQpkC+BjJaSGpdB5SX53kVQDu8KhP"
        "gfwHgGeFteWyxtjyE5wbmkWhynuHEfUtR8OQbKlPd2H3SbxzMujZkcPtzRkuHrfLs+26t+mBztqI16g94NpeEPX5/o/1gAPVXpKX"
        "ZnlhZKGqR4ffjWx7UgA/Ft2pft4ENOPMAZqTif85zj3C0G3cCufcUbTqhWFmaUMGFa6XZ0a14eLbUQo0Lr4/iowrlaPd0W250hmn"
        "m6kmIDrkZL7MdqwNAB/OAeDzBYF3e5OQjVsKUdXM4L4TaNB6by1sFUTTxjqZpBMmlEyv0/K5o42xqOvebHGojBHE6sL0XOMlVY0I"
        "FBsqtagVEA2AX87hmbCilcEZypstEUmMCI49JCfkTVTh8i5l2ea9DcA22S9aIaQpmRIAi5xzv5XZzu2SZnxj7gJwq6c+qUqxEcAP"
        "0Th6zHW4LvyrIlH1swFsAHCp2abB6LoVAB9yzm0s3P/HUMncSDCzdUa/x182XZK2FeOy/IUI5dmlu7TUPhsessR408dAfEjyKOhA"
        "kkEMOnblCuYRtlM12sG9kUBwG7q2qiMTbnjJ8owcCTWTG2GenYAy9UU/el1Cx7ZkhP8reL/3KbZsEHV2V3hBMLHcBGtIvsenkCLA"
        "NELOepq9VWKW0xwJKFYLlXY2KY/hiUty5iY4TvKXGsQXALOSFc7qJZ+ohCaA5BRZrgcCLCXUp1W27m4waaXEBeKAyIwwLVseJ/lV"
        "ktc1oaykmTpBskdigB8x0UyMJPyxEQd9RSzbIhPvTAXwIBqnWmrJrnhWHP/eCTR8kjcCeBrAC2gcHR51zp0K8N5L0PAaeIe0M1M+"
        "x5lHaxhwULd7WzVV7Qaw2Dn3tyJUFVcUJQqIF4tpqE/qDmUqgmdf9MurAI6i4dBuowR6RP+ckFFfEgAuxYBPy28A9DnnDnQ9a1Fs"
        "3yzfZ5mgFUYyq9ldTN7EY34CslqThGZatnvawNA0AgfyBt5BclskcDrNkR+w5qVXyUqBF0potpvkUpKjO6qmFKSPOaP7zZdMQqEE"
        "Pc0AzZOE0X93i+R4GFM21ZWdArTi5U3tRePo8FYA78441GJGf5NIv3cB+BOA3znnNnuaQmlhYq4Ty1otvja7rijWM9EIaukFcB3O"
        "dSuLlWNopM3bjkYS2k0AtolfT0eA6xiAAUGThKSfBLH0ALgGDUfOSd4jh9DwGlMnn31+uuNOZu/tCoD+mYShzHqrLAIDh/9dScY9"
        "1FLBx9LAw7M7AgPuGCNlpFzA5f/iJ6X/qs/dlgAAAABJRU5ErkJggg=="
    ),
    "plus": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAALb0lEQVR42u1cf+yVVRn/PO/3IkYoCIIQzhSTkBo1GZAIM1rNUgot"
        "HRb4h27FWjUGxX/Zj8VfbBFttZxuZq1JjpaaZFtOVyYwQUlpxQwbA5EQUJRfAt97309/3OfIw8M5773fe997vz/ibO/e9773fc97"
        "zuc8v85znvMA58v50p9FBkpDSIppk0TaRnNARPh/DaAClmkbKCK1Pr6f6fsEkPcXoNJPoCEGGMkxACYAGAXgMvf3YQBvAtgP4LB/"
        "3wCai0g+pADUzontNMlLAHwcwPUAZgCYCmAigEsaVPcOgAMAdgLYBmAzgG0ist/U3ZMapEEFoAKHQBEkxwJYAOA2BW586lUAeaSt"
        "WQGoWwA8AeBREdlrKb4bQJbOqoEK9PcMkr8g+QbPLjWSvSSrep2zccn12aq+W3P/HyG5juR8O5BhMAcDeBa4OSQfcx2s6pE3AZI9"
        "8oJ3clOvLX8lucC2zWj7AUl1mV5fQfJB15neBACWmqpNUGB4NkZ9Fkz73x9IfsyLloFKdUtJHnKdYYJ1UxR1iuTrJPea40QBqCkw"
        "LVWeJPn90FaSlQGhREhWRKSqJsh9AO7Qv6oAfCNrEWXwGoCtqgR2ANhtNK1VJJcCuBjAB1Vjz1LtfY15JlcF1BP5brj3HIC7ReTV"
        "0Pb+pLxhep5NcmcBq3oF8R+Sa0l+kuT72/j+BSRnkvwRyZcj1OdZu1evD5JcaPvQH+BV9LxQ2YOmgUyw8LMkF5Ec4UUAyYqeMz3E"
        "HeH+e89G6vgsySfMYMWUlW3PMi+Cug3eUgNaNUJ1obxA8hZfR7ta0QBbcfevJ/lUATXWTPtWmfZIN9n2awn2tJR4lOQKA3jWKVMi"
        "2J5OoS1RZZTijnBvdZmKpaG2VbatRswFO9rPk5wW09TNfssd0od3M2NSTTS2qB/snORpx86VToM3Q82MPNKYMKL3kbygK6PahKjR"
        "63sLQAyDfntH2mxkzWiSuyJyxYL3XW9Yt/jN2STn6zHPUJT0sZ7MDP7iBIjBmD9KckrpxrZpwO8S8sSD15JANpr2wYhR/DTJEUFD"
        "tyG7lyRADATxIskLS5PVBryv6gdOdwo8PU+OTMnCNz7djtlhQFycsFnDd35cinlj7LFJJN+JjFr44P3tyg4D4FTzDWvP1Uje3G7H"
        "DIgrE9wUbMdZbYNoqO+hyMdqxsYb1q4dZQD8sJOtlr0+VwZlGBDXR+R5uN7o3XKtgjfTCNncsdfxsoRulwEMsnYUyT3GfeZB/HLL"
        "nGUA3FAwSsvLUvvdBND17+ZI/4Ko+pfOt6VP3GUqn14wOv8oYzrWXwC6KenjBUTyxSIiyRq4ub6h17n7jwC+E1xBA2WNtjUMKQBW"
        "Ajhh+mbXZr5lXGXNGc16Hk3yrQgl5CQ3l21s9gcFOm77lVOUueG+aan+xgAIjfsC6kuMNed4FQBrFGjBECjal7VKZZnpZ01/L07h"
        "FQMwkPDtMKEUWnkPgD2oLx82T9YDuOiSp4jI39VbnSlwFp/blPpqXt5nfiREpEZyFOrrtmIoMoD1qIicBNAziGXfOYSkwKxzRBRC"
        "R64BMFX7mxVRYPh9na5B5IZNw3+/dx8ZCiXE1vwRwEldy6FZT6kAmOcUbBTA8OcNjuqCbHhdF4CGBPsaNs5JZiLyGoAXE/2bGyOc"
        "LCH/rkvc3yIi75IcSuzr2fhvETYGgOlBxNmXKl6gqlq/1r0cKns+RsYxc6TFDhTZpgAQfIwZ9eFWqC3VdBEhSd/HcL4SwDgABxRI"
        "ngWguWlDy3wlO4rkn9bRKmuHAKQTBc+c0vrbEh8WgAiX7cSZtWWavl+MevTYAWtwVyIzjHEKor2XaaN3FQGoIzgZQCtrreEbVxU8"
        "M5nkXu1cKxFXuYjs1HZ6EMP1PgBvqw1MYw/2APgAgJdNW88BEADGGvVtKbBXK06xrQB4AMBdzvxpS7474/7+djSttvVptXGPJijx"
        "OIAjiMcpjisypENjJzgtFD5wCPUI0bMoUBVKDmAmgLt1ULq7UN08hQPAZwDcqsD1OO7JlFD2uX6G8yRfaSU1UokZSpHsGYmzY1PY"
        "ArWxiekhI5P+ZktN3xtZoGRIMi94vyGAbIdFIoqnFZZt5plW65cybdhKk/eaKVVlk2qbs5SiUN68zbpz7V+tLLwqEco75GRGGOkx"
        "euxzLJSr7NgK4BkAn+qCHGu19AB4BcAGNZpr3gTT9ZIJCSo/0AyABxKyaDiA0UbAWpkBnaHcBOBGABe0SHkEcLnRtjQslwH4HoAX"
        "rBnRF/NPj80iciShgQHgfcaM82JjfyOfGEiO1yVM69CsdcqhGWnHpAKH6o0l+v+iMyh16Fbd90OZ4WdbFUtJenkYwEG1vD0FTAHw"
        "p5QAtxtp2jCkRxVpeh28njbkWGpXU+jTZK0/d/bwCQD/9YrWx9VlItJL8t8ArjaVhMpnNZqJtNoxnRrkJGsNOl9TkVH23o+w8jbT"
        "eaACgHsAvOGILekP3JYYndkqZPMBu12gfZ/gXNfnIGv/aZwtDd1Zm1wlYSQmA5ge88wO5mI08DgAn0hgs7EZh2oAcKvOB3ucZ1YA"
        "3NqGITtQS1jbvgnARTh7IS3I5mcbOlSNZ/aggminb+HZLykZ14YQgFSuWuRACnJwN4DtsaluVmCsPu4M5jAS1wKY32lzpovsm6lM"
        "v1odDdbJEMB6UpVrxWvwrGDCvF5VdyXilfj2UFqR0758UycLnn0B4Nd98hOY1fpHXPiu3aY1o0wq7KfYmBD/eJluT8sjURjbinZ7"
        "NtKkP4tM7qlUuWYIUd8q1B3JlvqC/fdz9XdmrY7OpoLIpTv12cEc3jbTbbyx4W17SY4sCm8rXAHT0flhYtqTA/ip2k61QbOh+cyU"
        "U3TgHzB2rnV7CYDVInIMrUZhmFF6soAKN+gzwwZhiO9PEv3KSe4gObzVXQG+U9PMhuhYkPm9tmElAJgKMm8bQAPenQ22bNxSirgw"
        "VPiDyAethl7cDogGwCkGtNNa/8kyKNBEpM7T+O4UQawrTdubTXyVhEKxW6WWtAuixiQ/Fdlo8wrJMX2OVz6X8ubpjiQmFMdukmNL"
        "TVRhqONKkm9HtJaNow6U2OdtD8apO0I3wyzV4x6Sl6acoU0QQKUBeLnZdDO3I7Msw8oLEpuZLYgrPdt0ypPcqM1mUL6SAM+y7vKy"
        "25ySIcvMtq8UiI9oHoXQkayvVOMOaZHqhpFck9gIbreure0oeBFZsqogR0LV5EZYaAegk/ai372ueWu2FGz/D+D91lNsp0EMo7va"
        "mRmp3ATrSX40QmFZiUouM/cu1z3LeRMJKNYplXY3KY+RicuazE1wguQvwya+CJg9NtlEAihxiSd8jPdUZdeDEZESa9NaW3d/TIkC"
        "JS4yS6G9iQQ4tjxD8uskr2pAWVkjc4LkBN0D/JixF5lI+NNrQFxRBtuWmXhnGoCHUF/VCp7sHufF8ffeRT0m+TnUo19fRX3p8JiI"
        "nIrI3hGoRw18SL8zR8+jzaNV/Ya4uW1wlO4CcI+I/EUjy9ryrEtZlKggXqiuoRU4E5gYWysOjY7ZWm8BOIZ6QLvdJTBB1yvGFtSX"
        "RYAL8TAA8BsAK0TkYL9nLUoZ23p9g2ZOi+WwiiXmaTbxmE9AVm2Q0CyU7c4aGJhLEZG8gXeRfCmRKCxvIj9g1aVXKUqBF0totovk"
        "cpLDu2qmlOUqN7bfHTq/jSXoaQRoM0kY/btbNMfDRZ2muk6nAO1xeVOno750+HkAHylY1GJBe7NEu3cC+DOAh0Vkk7MUap1aBJNu"
        "sHXw+NotEGpYz0F9V9R01KPzRzVZ7XHU0+ZtRz0J7UYAL4lIb7eA6xqAEUWTxbQfyfGqaa9APZBzonvkTdSjxkKQz36/J6Wb2Xv7"
        "BUC/JmEos9WIrmDv9Vsy7oGWCj6VBt4a4+8t8g/B/Xrny/nSx/I/XwJNvQxksNoAAAAASUVORK5CYII="
    ),
    "minus": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAKXElEQVR42u1cXaxdRRX+1j7ntoiFFuqFVgxC0aZUczU2t0hpo5iY"
        "GikWDaRoywMaJb7Y0IQ3iSb2iUTomyiJYmKsBCNCKyQqYJG2oZUGMLbRizaFUstty09LS+Gesz8fzhq67mJmn3PvPT/7XDvJztln"
        "/8ye+eZbPzOzZoCz6WzqZZKyFISkmDJJpGw0B0SE/9cAKmCZloEiUp/g+5m+TwB5rwCVHoGGGGAkLwQwD8BsABe7268DOAbgMIDX"
        "/fsG0FxE8mkFoFZObKVJXgDg0wCuBrAEwCIA8wFc0CS7NwGMAhgBsAfATgB7ROSwybuSaqS+AlCBQ2AEybkAVgH4qgJ3UepVAHmk"
        "rFkBqLsAbAHwkIgctIzvBpBtF9XAAv2/hORPSL7K8alOcoxkTc9zNk+5PlvTd+vu/nGSm0leaxsyNGY/gGeBW0by966CNT3yFkCy"
        "R17wTm7ytWkbyVW2bMbal5J1mZ5fSvLnrjJjCQAsm2otMDA8G2OfBdPee4Tkp7xqKSvrbiN51FWGCdFNMeodkq+QPGiOUwWgpsC0"
        "rDxN8gehrCSrpTAiJKsiUlMX5F4AN+mtGgBfyHrEGLwMYLcagX0ADhhLaw3JhwCcD+CjarGXqvX+uHkmVwNUiXw3XHsawK0i8mIo"
        "ey+ZN6C/V5EcKRBVbyD+TXITyc+T/OAUvj+D5DDJH5F8PsI+L9pjen6E5Gpbh16AV9Xf1SoeNAVkQoSfIrmG5LleBZCs6m+mh7gj"
        "XH/v2UgeXyK5xTRWzFjZ8qz3Kqjb4N1mQKtFWBfS30he5/OYqlU0wFbd9atJ/qmAjXVTvo2mPNJNsf1OQjwtE0+Q3GAAzzrlSgTf"
        "0xm0dWqMUtIRrt3VTsPS1Nqq2NYi7oJt7WdILo5Z6m50HY1LNd/4or6xc5LvOnGudhq8Jepm5JHChBa9l+SMrrRqC6pGz+8sADE0"
        "+o0dKbPRNXNI7o/oFQve971j3WMfNTONvzYBYnDmT5Bc2HZn2xTgtwl94sGrlq3LZHT3ugSIgRDPkjynbbragPdt/cC7/QZeBMS1"
        "CZ811OXHbdHbxh+7hOSbkVYLH/xZr/XdJEC8IyFNwXdcOmUQDfvuj3ysbny8gTIzrwDEByP6PJxv98NykwVv2CjZ3Fmukx1Rul1y"
        "c0jOJvmSGT7zIH590pJlANxa0Eq394voFtTvy5H6BVW1V/vbMiHpMpkPFbTO39vRHesxiKGH9HABSb42YZKYjH+a0H05yZU96Yi3"
        "mYXKroWqjuqRgYgnJ6SiApvUaX7N6Dyb6c5+03stSNsvHVlyI32LU/WNARAY9RU0phjrbuBVANytQAumQdK6bNIB2czUs67/1xbg"
        "lWyRR1wXLejBA+qpS7/qvphV1t9tTv+FOu+1Y5RJBpIUEamTnI3GvK0YRobh9YdE5DSASlniU9qQMgVmc4DC4EOdNlik9c2KRDj8"
        "/wwacxC5EdNw73fuI9MhhdiaPwA4jcZcTqhfXf+vMKKdBDDcvMaxLuiGV9CYALL3+j6JSE4yE5GXATybqN/yGHE8gDQMjF3fJSJv"
        "k5xO4uvF+K8RMQaAoaDi7EtV1xJ1NSJXupdDZs/EaBxTyGVmW6roIkKSvo7h9zIAgwBGFUiOA9BctKFlPpN9RfpP8yi9aFsAIlI2"
        "gjNzyzR1Px+N6LFRvUbPwHBxUEG01zLVCfuLANQWXABgoKTY5SIyouX0IIbzQwDeUB+Yxh+sAPgwgOcNHu8DEADmGvNtGTimGafE"
        "VgDcB+AW5/6UBjwt6+MAbgRwIsHEkwCOIx6nOFjUEwlgzXNWKHzgKBoRouMYqAYlBzAM4FZtlDL2j0NdvwjgBgWu4qQnU6IccvUM"
        "v5f4TKuplooRrYnrMgvjY1PKaKXrWq5ZBUaGJPOC95sCyKmISMTwlMoI69E2Q1dt8VorqaZiUitxLyXX+tXbhVc1wryjTmcEJl2o"
        "xyFrxgHkqjt2A3gCwBdK7MFUAPwTwFZ1muveBdP5knkJKRptBcBRZ4FDmglgjlGwVmdAeygrAXwOwIwyun967BSR4wkLDAAfMG6c"
        "N7CHWwHwGIAT6jjS6IwMjeDGvR7cUBANVny8Tx3pIFV2qYUY5gLAf72hrXoQ0FjQciQB4EIAj6UMhF1I0wcjL0iwbIECljt/+JQB"
        "kFGlqCMSYyT/BeAKk0nIfGmznsgUFHTPLbQSYNiNQAUAXwLwqiNbcjxwT6J1rlIlm0+X0egIM5e7Ogdx/YcZbGk6nLXDZRJaYgGA"
        "odjIbD8nY4EHAXw2gc32mGVOAbhb+4O2RxEml24osaM8afdGJWolgPMwfiItDBw81VJHw0yw/NkFH9oJlsp0EmEzkbbFTW2GOv/H"
        "xNMUMtBee9g5zKElrgRwrf1wn4OXqU6/Qgca7CBD0H+PqnGtNh2JNxPr83S23k+sk+Rj0wjAEIVxT0EE2sRC3QylH3Bzw3aZ1pJ+"
        "B9HM9V6sy9PySBTGngmv9jQArois+Qgs3DYNAAzsuy/CvnD+LfvsZFpnR0Hk0s2TyrxchmPYLbyxAVQHSc6aVBSG+cDKRPxcXRdQ"
        "D5YlIn8ifp+G5lVJPhepX2Df96ZEEAPiowUs3KrPDPRhiO89iXrlJPeRnBkkcSomHiQXmwXRsSDzO23B+gS8m5ss2biuLTresPCH"
        "kQ9aC7227CAao7FCXbQUITa3zUCaRXzVhEGxvZV1ZQXRMG+FrkhiwnAcIDm3rRtVGFG+jOQbEatl46gDE0ux7CEYjCbg5WbRzfKO"
        "uGdGlFclFjNbEO/wYtMrV8X0rL6RAM+KbmdXHZiWXG+WfaVAfED3UQgVyXrEugGSdycWgtula5u60uBGl2ws2COhZvZGWG0boJNA"
        "+tXrum/NroLl/wG833jGdsua3WUKVy/Ym+BBkp+MOLJZm9g2juEkP6JrlvMWNqDYrCzt7hCd0YnrW9yb4BTJX4SRjQiYlVQgt3lO"
        "3MYTPsZ7kYrrkYhKiZVpk827l37VGl3NGXNMY8A+QfK7JC9vwqysmTuhw27rdFn/6YJv+oHSDe0Q23ZuvLMYwP1ozGqFQKSKmy7w"
        "195GIyb5aTSiX19EY+rwLRF5J6J7z0UjauBj+p1l+jvHPFrTb9i62aCn/QC+KSJ/0ciyKc0iSruYqCCeA2AjgA04E5gYmysOhY75"
        "Wq8BeAuNgHa7SmCezlfMLcgviwAX4mEA4FcANojIkZ7vWpRytvX8GrNohYmd1WwvptWNx/wGZLUmG5qF9ILzBso5hhnZN/AWM1zk"
        "NwrLW9gfsOa2VynaAi+2odl+kreTnNlVN6VdQ+XG97tJdxKKbdDTDNBWNmH07+7SPR7O6zTrOr0FaMXtmzoEYA2A6wF8AvFZwRBF"
        "mipvlij3CIA/Avi1iOxwnkK9U+tapBtirZWmXQKhjvUyNFZFDQG4HO8PK0ulk2hsm/cCGpvQbgfwnIiMdQu4rgEYMTRZzPqRvEgt"
        "7aVoBHLOd48cQyNqLAT5HPZrUrq5e29PAHSstMysT1ZF4Mzkf0824y7bVvCpbeCtM/7e0oNpuF7vbDqbJpj+BxOq30JYPVM1AAAA"
        "AElFTkSuQmCC"
    ),
}

FALLBACK = {"lock": "🔒", "unlock": "🔓", "ghost": "👻", "reveal": "👁️", "claim": "👑",
            "manage": "🎛️", "rename": "✏️", "info": "ℹ️", "plus": "➕", "minus": "➖"}
ICONS = dict(FALLBACK)          # replaced with application emojis at load time

ROW1 = ("lock", "unlock", "ghost", "reveal", "claim")
ROW2 = ("manage", "rename", "info", "plus", "minus")
USAGE = [("lock", "Lock", "the voice channel"), ("unlock", "Unlock", "the voice channel"),
         ("ghost", "Ghost", "the voice channel"), ("reveal", "Reveal", "the voice channel"),
         ("claim", "Claim", "the voice channel"), ("manage", "Manage", "permit or reject members"),
         ("rename", "Rename", "the voice channel"), ("info", "View", "channel information"),
         ("plus", "Increase", "the user limit"), ("minus", "Decrease", "the user limit")]

db = {}
if os.path.exists(DATA_FILE):
    try:
        with open(DATA_FILE) as f:
            db = json.load(f)
    except (OSError, json.JSONDecodeError):
        print("[voicemaster] could not read voicemaster_data.json, starting fresh")


def save():
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(db, f, indent=2)
    os.replace(tmp, DATA_FILE)


def conf(guild_id) -> dict:
    c = db.setdefault(str(guild_id), {})
    c.setdefault("hub", None)
    c.setdefault("hub2", None)
    c.setdefault("randomhub", None)
    c.setdefault("randomcats", [])
    c.setdefault("categories", [])   # [{"id": int|None, "prefix": str, "sequential": bool}]
    c.setdefault("default_name", DEFAULT_NAME)
    c.setdefault("autounmute", [None, None])
    c.setdefault("temp", {})         # channel_id -> {"owner": int, "cat": int|None, "num": int|None}
    return c


async def send(ctx, content=None, **kwargs):
    kwargs.setdefault("allowed_mentions", discord.AllowedMentions.none())
    return await ctx.send(content, **kwargs)


def staff():
    async def predicate(ctx):
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        if await ctx.bot.is_owner(ctx.author):
            return True
        if ctx.author.guild_permissions.manage_guild or ctx.author.guild_permissions.administrator:
            return True
        raise commands.MissingPermissions(["manage_guild"])
    return commands.check(predicate)


def owner_check():
    """Server owner or bot owner."""
    async def predicate(ctx):
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        if ctx.author == ctx.guild.owner or await ctx.bot.is_owner(ctx.author):
            return True
        raise commands.CheckFailure("Only the server owner or bot owner can manage VoiceMaster categories.")
    return commands.check(predicate)


def parse_on(text: str) -> bool:
    t = text.lower()
    if t in ("on", "true", "enable", "yes"):
        return True
    if t in ("off", "false", "disable", "no"):
        return False
    raise commands.BadArgument("Use on or off.")


# --------------------------------------------------------------------------
# Panel text
# --------------------------------------------------------------------------
def welcome_text(mention: str) -> str:
    return f"Welcome to your voice channel, {mention}\nUse the buttons below to control your voice channel."


def usage_text() -> str:
    return "\n".join(f"> {ICONS[k]} - `{label}` {rest}" for k, label, rest in USAGE)


# --------------------------------------------------------------------------
# Modals / pickers
# --------------------------------------------------------------------------
class NameModal(discord.ui.Modal, title="Rename channel"):
    value = discord.ui.TextInput(label="New name", max_length=100)

    def __init__(self, channel: discord.VoiceChannel):
        super().__init__()
        self.channel = channel

    async def on_submit(self, interaction: discord.Interaction):
        name = self.value.value[:100]
        await self.channel.edit(name=name, reason="VoiceMaster rename")
        await interaction.response.send_message(f"✏️ Renamed to **{name}**.", ephemeral=True)


class ManageView(discord.ui.View):
    """Ephemeral picker: choose members, then Permit or Reject them."""

    def __init__(self, channel: discord.VoiceChannel, owner_id: int):
        super().__init__(timeout=120)
        self.channel, self.owner_id = channel, owner_id
        self.select = discord.ui.UserSelect(placeholder="Select members…", min_values=1, max_values=10)
        self.select.callback = self.on_select
        self.add_item(self.select)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Only the channel owner can use this.", ephemeral=True)
            return False
        return True

    async def on_select(self, interaction: discord.Interaction):
        await interaction.response.defer()

    async def apply(self, interaction: discord.Interaction, allow: bool):
        picked = [u for u in self.select.values if not u.bot and u.id != self.owner_id]
        if not picked:
            return await interaction.response.send_message("Pick at least one member first.", ephemeral=True)
        names = []
        for u in picked:
            member = interaction.guild.get_member(u.id)
            if member is None:
                continue
            if allow:
                await self.channel.set_permissions(member, connect=True, view_channel=True,
                                                   reason="VoiceMaster permit")
            else:
                await self.channel.set_permissions(member, connect=False, reason="VoiceMaster reject")
                if member.voice and member.voice.channel == self.channel:
                    try:
                        await member.move_to(None)
                    except discord.HTTPException:
                        pass
            names.append(member.display_name)
        verb = "✅ Permitted" if allow else "🚫 Rejected"
        await interaction.response.send_message(f"{verb}: {', '.join(names) or 'nobody'}", ephemeral=True)

    @discord.ui.button(label="Permit", style=discord.ButtonStyle.success)
    async def permit(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.apply(interaction, True)

    @discord.ui.button(label="Reject", style=discord.ButtonStyle.danger)
    async def reject(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.apply(interaction, False)


# --------------------------------------------------------------------------
# Button handling
# --------------------------------------------------------------------------
async def handle_button(interaction: discord.Interaction, key: str):
    guild = interaction.guild
    c = conf(guild.id)
    entry = c["temp"].get(str(interaction.channel_id))
    ch = guild.get_channel(interaction.channel_id)

    async def reply(text):
        await interaction.response.send_message(text, ephemeral=True)

    if not entry or not isinstance(ch, discord.VoiceChannel):
        return await reply("This isn't an active VoiceMaster channel.")
    user = interaction.user

    if key == "info":
        ow = ch.overwrites_for(guild.default_role)
        e = discord.Embed(title=ch.name, color=0x2B2D31)
        e.add_field(name="Owner", value=f"<@{entry['owner']}>")
        e.add_field(name="Members", value=str(len(ch.members)))
        e.add_field(name="User limit", value=str(ch.user_limit or "No limit"))
        e.add_field(name="Locked", value="Yes" if ow.connect is False else "No")
        e.add_field(name="Hidden", value="Yes" if ow.view_channel is False else "No")
        e.add_field(name="Bitrate", value=f"{ch.bitrate // 1000} kbps")
        return await interaction.response.send_message(embed=e, ephemeral=True)

    if key == "claim":
        owner = guild.get_member(entry["owner"])
        if owner and owner.voice and owner.voice.channel == ch:
            return await reply("The owner is still in the channel.")
        if not (user.voice and user.voice.channel == ch):
            return await reply("Join the channel first.")
        if owner:
            await ch.set_permissions(owner, manage_channels=None, move_members=None, reason="VoiceMaster claim")
        await ch.set_permissions(user, view_channel=True, connect=True, manage_channels=True,
                                 move_members=True, reason="VoiceMaster claim")
        entry["owner"] = user.id
        save()
        return await reply("👑 You now own this channel.")

    if user.id != entry["owner"]:
        return await reply("Only the channel owner can use this.")

    everyone = guild.default_role
    if key == "lock":
        await ch.set_permissions(everyone, connect=False, reason="VoiceMaster lock")
        return await reply("🔒 Channel locked.")
    if key == "unlock":
        await ch.set_permissions(everyone, connect=None, reason="VoiceMaster unlock")
        return await reply("🔓 Channel unlocked.")
    if key == "ghost":
        await ch.set_permissions(everyone, view_channel=False, reason="VoiceMaster ghost")
        return await reply("👻 Channel hidden.")
    if key == "reveal":
        await ch.set_permissions(everyone, view_channel=None, reason="VoiceMaster reveal")
        return await reply("👁️ Channel visible again.")
    if key == "rename":
        return await interaction.response.send_modal(NameModal(ch))
    if key == "manage":
        return await interaction.response.send_message("Select members to permit or reject:",
                                                       view=ManageView(ch, entry["owner"]), ephemeral=True)
    if key in ("plus", "minus"):
        cur = ch.user_limit or len(ch.members)
        new = min(cur + 1, 99) if key == "plus" else max(cur - 1, 0)
        await ch.edit(user_limit=new or None, reason="VoiceMaster limit")
        return await reply(f"👥 User limit: {new or 'no limit'}")


class VMButton(discord.ui.Button):
    """Icon-only grey button; persists across restarts via its custom_id."""

    def __init__(self, key: str, row: Optional[int] = None):
        super().__init__(style=discord.ButtonStyle.secondary, emoji=ICONS[key],
                         custom_id=f"vm:{key}", row=row)
        self.key = key

    async def callback(self, interaction: discord.Interaction):
        await handle_button(interaction, self.key)


# --------------------------------------------------------------------------
# Panel views
# --------------------------------------------------------------------------
HAS_V2 = hasattr(discord.ui, "LayoutView")     # discord.py 2.6+

if HAS_V2:
    class PanelLayout(discord.ui.LayoutView):
        """Container (welcome + logo + button usage) with two button rows under it."""

        def __init__(self, mention: str = "owner", logo: Optional[str] = None):
            super().__init__(timeout=None)
            welcome = discord.ui.TextDisplay(welcome_text(mention))
            top = (discord.ui.Section(welcome, accessory=discord.ui.Thumbnail(logo)) if logo else welcome)
            self.add_item(discord.ui.Container(
                discord.ui.TextDisplay("**VoiceMaster**"),
                top,
                discord.ui.Separator(visible=False),
                discord.ui.TextDisplay("### Button Usage\n" + usage_text()),
            ))
            self.add_item(discord.ui.ActionRow(*[VMButton(k) for k in ROW1]))
            self.add_item(discord.ui.ActionRow(*[VMButton(k) for k in ROW2]))


class PanelClassic(discord.ui.View):
    """Fallback for discord.py < 2.6: an embed plus the same two button rows."""

    def __init__(self):
        super().__init__(timeout=None)
        for k in ROW1:
            self.add_item(VMButton(k, row=0))
        for k in ROW2:
            self.add_item(VMButton(k, row=1))


def build_panel(member: discord.Member, logo: Optional[str], classic: bool = False):
    """Returns (view, embed_or_None). classic=True forces the embed version."""
    if HAS_V2 and not classic:
        return PanelLayout(member.mention, logo), None
    embed = discord.Embed(color=0x2B2D31, description=welcome_text(member.mention) +
                          "\n\n**Button Usage**\n" + usage_text())
    embed.set_author(name="VoiceMaster")
    if logo:
        embed.set_thumbnail(url=logo)
    return PanelClassic(), embed


class VoiceMaster(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.last_create = {}

    # ---- lifecycle -------------------------------------------------------
    async def load_icons(self):
        """Upload the bundled white icons once as application emojis (discord.py 2.5+)."""
        if not hasattr(self.bot, "fetch_application_emojis"):
            print("[voicemaster] discord.py is older than 2.5: using normal emoji for the panel icons")
            return
        try:
            existing = {e.name: e for e in await self.bot.fetch_application_emojis()}
            for key, data in ICON_B64.items():
                name = f"vm_{key}"
                emoji = existing.get(name)
                if emoji is None:
                    emoji = await self.bot.create_application_emoji(name=name, image=base64.b64decode(data))
                ICONS[key] = emoji
            print("[voicemaster] panel icons ready")
        except Exception as e:
            print(f"[voicemaster] couldn't set up the panel icons ({e!r}); using normal emoji")

    def logo(self):
        """(url_for_the_thumbnail, discord.File_or_None)"""
        url = os.getenv("VM_LOGO_URL")
        if url:
            return url, None
        for path in (pathlib.Path(LOGO_FILE), pathlib.Path(__file__).with_name(LOGO_FILE)):
            if path.exists():
                return f"attachment://{LOGO_FILE}", discord.File(path, filename=LOGO_FILE)
        return self.bot.user.display_avatar.url, None

    async def send_panel(self, channel, member):
        """Posts the interface in the voice channel's chat and pings the member.
        If the new layout is rejected, the error is printed and the embed version is sent instead."""
        ping = discord.AllowedMentions(users=[member])
        logo, logo_file = self.logo()
        try:
            view, embed = build_panel(member, logo)
            kwargs = {"view": view, "allowed_mentions": ping}
            if embed is not None:
                kwargs["embed"] = embed
                kwargs["content"] = member.mention
            if logo_file:
                kwargs["file"] = logo_file
            return await channel.send(**kwargs)
        except Exception as e:
            print(f"[voicemaster] couldn't send the new panel layout: {e!r}")
            traceback.print_exc()
        view, embed = build_panel(member, self.bot.user.display_avatar.url, classic=True)
        return await channel.send(content=member.mention, embed=embed, view=view, allowed_mentions=ping)

    async def cog_load(self):
        print(f"[voicemaster] v3 loaded - discord.py {discord.__version__} - new panel layout: "
              f"{'ON' if HAS_V2 else 'OFF (needs discord.py 2.6+, using the embed version)'}")
        await self.load_icons()
        self.bot.add_view(PanelLayout() if HAS_V2 else PanelClassic())
        # Drop temp channels that emptied or vanished while the bot was offline.
        for gid, c in list(db.items()):
            guild = self.bot.get_guild(int(gid))
            for cid in list(c.get("temp", {})):
                ch = guild.get_channel(int(cid)) if guild else None
                if ch is None:
                    c["temp"].pop(cid, None)
                elif not ch.members:
                    try:
                        await ch.delete(reason="VoiceMaster cleanup")
                    except discord.HTTPException:
                        pass
                    c["temp"].pop(cid, None)
        save()

    async def cog_check(self, ctx):
        if ctx.guild is None:
            raise commands.NoPrivateMessage()
        return True

    async def cog_command_error(self, ctx, error):
        error = getattr(error, "original", error)
        if isinstance(error, commands.CommandNotFound):
            return
        if isinstance(error, commands.MissingPermissions):
            msg = "You don't have permission to use that."
        elif isinstance(error, (commands.MissingRequiredArgument, commands.BadArgument,
                                commands.TooManyArguments, commands.BadUnionArgument)):
            msg = f"Usage: `{ctx.clean_prefix}{ctx.command.qualified_name} {ctx.command.signature}`"
        elif isinstance(error, discord.Forbidden):
            msg = "I'm missing permissions or my role is too low for that."
        elif isinstance(error, commands.NoPrivateMessage):
            msg = "Server only."
        elif isinstance(error, commands.CheckFailure):
            msg = str(error) or "You can't use that here."
        else:
            traceback.print_exception(type(error), error, error.__traceback__)
            msg = f"Something went wrong: `{error}`"
        await send(ctx, msg)

    # ======================================================================
    # VOICE LOGIC
    # ======================================================================
    def slot_category(self, guild, c, slot: int, hub: discord.VoiceChannel):
        """Return (category_channel_or_None, slot_index_or_None) for a hub."""
        cats = c["categories"]
        for idx in (slot - 1, 0):
            if 0 <= idx < len(cats) and cats[idx].get("id"):
                cat = guild.get_channel(cats[idx]["id"])
                if isinstance(cat, discord.CategoryChannel):
                    return cat, idx
        return hub.category, None

    def render_name(self, member, c, idx) -> tuple:
        template = c["default_name"] or DEFAULT_NAME
        name = (template.replace("{user}", member.display_name)
                .replace("{username}", member.name)
                .replace("{display}", member.display_name))
        prefix, num = "", None
        if idx is not None:
            slot = c["categories"][idx]
            prefix = slot.get("prefix") or ""
            if slot.get("sequential"):
                used = {t.get("num") for t in c["temp"].values()
                        if t.get("cat") == slot.get("id") and t.get("num")}
                num = 1
                while num in used:
                    num += 1
        parts = [prefix, f"{num}" if num else "", name]
        return " ".join(p for p in parts if p).strip()[:100] or "VC", num

    async def create_vc(self, member, c, slot: int, hub):
        now = time.time()
        if now - self.last_create.get(member.id, 0) < 3:   # anti join-spam
            return
        self.last_create[member.id] = now
        guild = member.guild
        cat, idx = self.slot_category(guild, c, slot, hub)
        name, num = self.render_name(member, c, idx)
        ow = dict(cat.overwrites) if cat else {}
        ow[member] = discord.PermissionOverwrite(view_channel=True, connect=True,
                                                 manage_channels=True, move_members=True)
        ch = None
        try:
            ch = await guild.create_voice_channel(name, category=cat, overwrites=ow,
                                                  reason=f"VoiceMaster: {member}")
            c["temp"][str(ch.id)] = {"owner": member.id, "cat": cat.id if cat else None, "num": num}
            save()
            await member.move_to(ch)
        except discord.HTTPException:
            # couldn't create or move them (they left?) -> tidy up
            if ch:
                c["temp"].pop(str(ch.id), None)
                save()
                try:
                    await ch.delete()
                except discord.HTTPException:
                    pass
            return
        try:
            await self.send_panel(ch, member)
        except Exception:
            print("[voicemaster] couldn't send any panel:")
            traceback.print_exc()

    async def random_join(self, member, c):
        guild = member.guild
        hubs = {c["hub"], c["hub2"], c["randomhub"]}
        pool = []
        for cid in c["randomcats"]:
            cat = guild.get_channel(cid)
            if isinstance(cat, discord.CategoryChannel):
                pool += [v for v in cat.voice_channels if v.id not in hubs
                         and v.permissions_for(member).connect]
        busy = [v for v in pool if v.members]
        target = random.choice(busy or pool) if pool else None
        try:
            await member.move_to(target)   # None disconnects if there is nowhere to go
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if member.bot:
            return
        c = conf(member.guild.id)
        if after.channel and after.channel != before.channel:
            cid = after.channel.id
            if cid == c["hub"]:
                await self.create_vc(member, c, 1, after.channel)
            elif cid == c["hub2"]:
                await self.create_vc(member, c, 2, after.channel)
            elif cid == c["randomhub"]:
                await self.random_join(member, c)
            if cid in [x for x in c["autounmute"] if x] and after.mute:
                try:
                    await member.edit(mute=False, reason="VoiceMaster auto-unmute")
                except discord.HTTPException:
                    pass
        if before.channel and before.channel != after.channel:
            if str(before.channel.id) in c["temp"] and not before.channel.members:
                c["temp"].pop(str(before.channel.id), None)
                save()
                try:
                    await before.channel.delete(reason="VoiceMaster: channel empty")
                except discord.HTTPException:
                    pass

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        c = db.get(str(channel.guild.id))
        if not c:
            return
        changed = c.get("temp", {}).pop(str(channel.id), None) is not None
        for key in ("hub", "hub2", "randomhub"):
            if c.get(key) == channel.id:
                c[key] = None
                changed = True
        if channel.id in c.get("autounmute", []):
            c["autounmute"] = [None if x == channel.id else x for x in c["autounmute"]]
            changed = True
        if changed:
            save()

    # ======================================================================
    # COMMANDS
    # ======================================================================
    @commands.group(name="vm", invoke_without_command=True)
    @staff()
    async def vm(self, ctx):
        p = ctx.clean_prefix + "vm"
        c = conf(ctx.guild.id)

        def ch(i):
            return f"<#{i}>" if i else "not set"

        await send(ctx, embed=discord.Embed(
            title="VoiceMaster",
            description=(
                f"**Setup:** `{p} setup` · `{p} hub set|create` · `{p} hub2 set|create|remove`\n"
                f"**Categories (owner):** `{p} category add|remove|set|list|prefix|sequential`\n"
                f"**Default name:** `{p} default name [template]` (`{{user}}`, `{{username}}`)\n"
                f"**Random hub:** `{p} randomhub set` · `{p} randomhub category add|remove`\n"
                f"**Auto-unmute:** `{p} autounmute set` · `{p} autounmute2 set`\n\n"
                f"Hub: {ch(c['hub'])} · Hub 2: {ch(c['hub2'])} · Random: {ch(c['randomhub'])}\n"
                f"Template: `{c['default_name']}`\n"
                f"Preview the interface: `{p} panel`")).set_footer(text="VoiceMaster v3 (new panel)"))

    # ---- setup / hubs -------------------------------------------------------
    @vm.command(name="setup")
    @staff()
    async def vm_setup(self, ctx):
        c = conf(ctx.guild.id)
        cat = None
        if c["categories"] and c["categories"][0].get("id"):
            cat = ctx.guild.get_channel(c["categories"][0]["id"])
        if not isinstance(cat, discord.CategoryChannel):
            cat = await ctx.guild.create_category("VoiceMaster", reason="VoiceMaster setup")
            if c["categories"]:
                c["categories"][0]["id"] = cat.id
            else:
                c["categories"].append({"id": cat.id, "prefix": "", "sequential": False})
        hub = await ctx.guild.create_voice_channel("Join to Create", category=cat,
                                                   reason="VoiceMaster setup")
        c["hub"] = hub.id
        save()
        await send(ctx, f"✅ VoiceMaster ready. Join {hub.mention} to get your own channel "
                        f"(category: **{cat.name}**, slot 1).")

    @vm.group(name="hub", invoke_without_command=True)
    @staff()
    async def vm_hub(self, ctx):
        await send(ctx, f"Usage: `{ctx.clean_prefix}vm hub set <channelID>` or "
                        f"`{ctx.clean_prefix}vm hub create [name]`")

    @vm_hub.command(name="set")
    @staff()
    async def vm_hub_set(self, ctx, channel: discord.VoiceChannel):
        conf(ctx.guild.id)["hub"] = channel.id
        save()
        await send(ctx, f"✅ Primary hub is now {channel.mention}.")

    @vm_hub.command(name="create")
    @staff()
    async def vm_hub_create(self, ctx, *, name: str = "Join to Create"):
        c = conf(ctx.guild.id)
        cat = None
        if c["categories"] and c["categories"][0].get("id"):
            cat = ctx.guild.get_channel(c["categories"][0]["id"])
        ch = await ctx.guild.create_voice_channel(name[:100], category=cat if isinstance(cat, discord.CategoryChannel) else None)
        c["hub"] = ch.id
        save()
        await send(ctx, f"✅ Created primary hub {ch.mention}.")

    @vm.group(name="hub2", invoke_without_command=True)
    @staff()
    async def vm_hub2(self, ctx):
        await send(ctx, f"Usage: `{ctx.clean_prefix}vm hub2 set <channelID>` · `create [name]` · `remove`")

    @vm_hub2.command(name="set")
    @staff()
    async def vm_hub2_set(self, ctx, channel: discord.VoiceChannel):
        conf(ctx.guild.id)["hub2"] = channel.id
        save()
        await send(ctx, f"✅ Secondary hub is now {channel.mention}.")

    @vm_hub2.command(name="create")
    @staff()
    async def vm_hub2_create(self, ctx, *, name: str = "Join to Create 2"):
        c = conf(ctx.guild.id)
        cats = c["categories"]
        cat = ctx.guild.get_channel(cats[1]["id"]) if len(cats) > 1 and cats[1].get("id") else None
        ch = await ctx.guild.create_voice_channel(name[:100], category=cat if isinstance(cat, discord.CategoryChannel) else None)
        c["hub2"] = ch.id
        save()
        await send(ctx, f"✅ Created secondary hub {ch.mention}.")

    @vm_hub2.command(name="remove")
    @staff()
    async def vm_hub2_remove(self, ctx):
        c = conf(ctx.guild.id)
        if not c["hub2"]:
            return await send(ctx, "No secondary hub is set.")
        c["hub2"] = None
        save()
        await send(ctx, "🗑️ Secondary hub removed (the channel itself was left in place).")

    # ---- categories (server owner / bot owner) -----------------------------
    @vm.group(name="category", invoke_without_command=True)
    @owner_check()
    async def vm_category(self, ctx):
        p = ctx.clean_prefix + "vm category"
        await send(ctx, f"`{p} add [name]` · `{p} remove <slot>` · `{p} set <slot> <categoryID>` · "
                        f"`{p} list` · `{p} prefix <slot> <text>` · `{p} sequential <slot> <on/off>`")

    def _slot(self, c, slot: int):
        if slot < 1 or slot > len(c["categories"]):
            raise commands.BadArgument("No such slot.")
        return c["categories"][slot - 1]

    @vm_category.command(name="add")
    @owner_check()
    async def vm_category_add(self, ctx, *, name: str = None):
        c = conf(ctx.guild.id)
        if len(c["categories"]) >= MAX_CATEGORIES:
            return await send(ctx, f"You can have at most {MAX_CATEGORIES} categories.")
        n = len(c["categories"]) + 1
        cat = await ctx.guild.create_category((name or f"VoiceMaster {n}")[:100], reason="VoiceMaster category")
        c["categories"].append({"id": cat.id, "prefix": "", "sequential": False})
        save()
        await send(ctx, f"✅ Added category **{cat.name}** as slot {n}.")

    @vm_category.command(name="remove")
    @owner_check()
    async def vm_category_remove(self, ctx, slot: int):
        c = conf(ctx.guild.id)
        removed = self._slot(c, slot)
        c["categories"].pop(slot - 1)
        save()
        await send(ctx, f"🗑️ Removed slot {slot} (<#{removed['id']}>). The Discord category was left in place.")

    @vm_category.command(name="set")
    @owner_check()
    async def vm_category_set(self, ctx, slot: int, category: discord.CategoryChannel):
        c = conf(ctx.guild.id)
        if slot == len(c["categories"]) + 1 and slot <= MAX_CATEGORIES:
            c["categories"].append({"id": category.id, "prefix": "", "sequential": False})
        else:
            self._slot(c, slot)["id"] = category.id
        save()
        await send(ctx, f"✅ Slot {slot} is now **{category.name}**.")

    @vm_category.command(name="list")
    @owner_check()
    async def vm_category_list(self, ctx):
        c = conf(ctx.guild.id)
        if not c["categories"]:
            return await send(ctx, "No categories configured. Use `vm setup` or `vm category add`.")
        lines = [f"`{i}.` <#{s['id']}> · prefix: `{s.get('prefix') or '-'}` · "
                 f"numbered: {'on' if s.get('sequential') else 'off'}"
                 for i, s in enumerate(c["categories"], 1)]
        await send(ctx, embed=discord.Embed(title="VoiceMaster categories", description="\n".join(lines)))

    @vm_category.command(name="prefix")
    @owner_check()
    async def vm_category_prefix(self, ctx, slot: int, *, text: str):
        c = conf(ctx.guild.id)
        self._slot(c, slot)["prefix"] = "" if text.lower() in ("none", "off", "clear") else text[:20]
        save()
        await send(ctx, f"✅ Slot {slot} prefix is now `{c['categories'][slot - 1]['prefix'] or '-'}`.")

    @vm_category.command(name="sequential")
    @owner_check()
    async def vm_category_sequential(self, ctx, slot: int, state: str):
        c = conf(ctx.guild.id)
        on = parse_on(state)
        self._slot(c, slot)["sequential"] = on
        save()
        await send(ctx, f"🔢 Numbered names for slot {slot}: **{'on' if on else 'off'}**.")

    # ---- default name -----------------------------------------------------
    @vm.group(name="default", invoke_without_command=True)
    @staff()
    async def vm_default(self, ctx):
        await send(ctx, f"Usage: `{ctx.clean_prefix}vm default name [template]`")

    @vm_default.command(name="name")
    @staff()
    async def vm_default_name(self, ctx, *, template: str = None):
        c = conf(ctx.guild.id)
        if not template:
            c["default_name"] = DEFAULT_NAME
            save()
            return await send(ctx, f"♻️ Template reset to `{DEFAULT_NAME}`.")
        c["default_name"] = template[:90]
        save()
        await send(ctx, f"✅ New voice channels will be named `{c['default_name']}` "
                        f"(`{{user}}` = display name, `{{username}}` = account name).")

    # ---- random hub -------------------------------------------------------
    @vm.group(name="randomhub", invoke_without_command=True)
    @staff()
    async def vm_randomhub(self, ctx):
        p = ctx.clean_prefix + "vm randomhub"
        await send(ctx, f"`{p} set <channelID>` · `{p} category add|remove <categoryID>`")

    @vm_randomhub.command(name="set")
    @staff()
    async def vm_randomhub_set(self, ctx, channel: discord.VoiceChannel):
        conf(ctx.guild.id)["randomhub"] = channel.id
        save()
        await send(ctx, f"🎲 Random hub is now {channel.mention}.")

    @vm_randomhub.group(name="category", invoke_without_command=True)
    @staff()
    async def vm_randomhub_category(self, ctx):
        c = conf(ctx.guild.id)
        await send(ctx, "**Allowed categories**\n" + ("\n".join(f"<#{i}>" for i in c["randomcats"]) or "None")
                   + f"\nUse `{ctx.clean_prefix}vm randomhub category add|remove <categoryID>`.")

    @vm_randomhub_category.command(name="add")
    @staff()
    async def vm_randomhub_category_add(self, ctx, category: discord.CategoryChannel):
        c = conf(ctx.guild.id)
        if category.id not in c["randomcats"]:
            c["randomcats"].append(category.id)
        save()
        await send(ctx, f"✅ **{category.name}** is now allowed for the random hub.")

    @vm_randomhub_category.command(name="remove")
    @staff()
    async def vm_randomhub_category_remove(self, ctx, category: discord.CategoryChannel):
        c = conf(ctx.guild.id)
        if category.id in c["randomcats"]:
            c["randomcats"].remove(category.id)
        save()
        await send(ctx, f"🗑️ **{category.name}** removed from the random hub.")

    # ---- auto-unmute ------------------------------------------------------
    @vm.group(name="autounmute", invoke_without_command=True)
    @staff()
    async def vm_autounmute(self, ctx):
        await send(ctx, f"Usage: `{ctx.clean_prefix}vm autounmute set <channelID>`")

    @vm_autounmute.command(name="set")
    @staff()
    async def vm_autounmute_set(self, ctx, channel: discord.VoiceChannel):
        conf(ctx.guild.id)["autounmute"][0] = channel.id
        save()
        await send(ctx, f"🔊 Auto-unmute channel 1 is now {channel.mention}.")

    @vm.group(name="autounmute2", invoke_without_command=True)
    @staff()
    async def vm_autounmute2(self, ctx):
        await send(ctx, f"Usage: `{ctx.clean_prefix}vm autounmute2 set <channelID>`")

    @vm_autounmute2.command(name="set")
    @staff()
    async def vm_autounmute2_set(self, ctx, channel: discord.VoiceChannel):
        conf(ctx.guild.id)["autounmute"][1] = channel.id
        save()
        await send(ctx, f"🔊 Auto-unmute channel 2 is now {channel.mention}.")

    @vm.command(name="panel")
    @staff()
    async def vm_panel(self, ctx):
        """Preview the panel in the current channel (handy for checking the look)."""
        await self.send_panel(ctx.channel, ctx.author)


async def setup(bot):
    """Registers after the bot is ready (every other cog has loaded), and skips any command
    name or alias another cog already owns instead of failing."""
    cog = VoiceMaster(bot)

    async def register():
        try:
            await bot.wait_until_ready()
            taken = bot.all_commands
            clash = [c.name for c in cog.get_commands() if c.name in taken]
            if clash:
                print(f"[voicemaster] skipped (name already used by another cog): {', '.join(clash)}")
                cog.__cog_commands__ = tuple(c for c in cog.__cog_commands__ if c.name not in taken)
            await bot.add_cog(cog)
            print("[voicemaster] commands registered")
        except Exception:
            traceback.print_exc()

    bot._voicemaster_register_task = asyncio.create_task(register())
