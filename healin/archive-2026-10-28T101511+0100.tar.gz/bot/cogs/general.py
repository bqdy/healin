import discord
from discord import ui
from discord.ext import commands

# Order matches the overview page. Names must match each cog's `name=`.
CATEGORIES = [
    "AntiNuke",
    "Role Limits",
    "Roles",
    "Vanity",
    "Aliases",
    "Server Configuration",
    "Live Channel Counters",
    "Activity Roles",
    "Event Logging",
    "Force Management",
    "Vouch",
    "Giveaway",
    "Moderation",
    "Tickets",
    "Disconnect Security",
    "VoiceMaster",
    "VC Commands",
    "VC Utility",
    "Rank Management",
    "Community Utilities",
    "General",
]


def overview_text(bot: commands.Bot) -> str:
    header = f"# Bot Overview\n\n**Bot:** {bot.bot_name}\n**Prefix:** {bot.prefix_display}"
    if bot.credit:
        header += f"\n**Created by:** {bot.credit}"

    lines = []
    for name in CATEGORIES:
        cog = bot.get_cog(name)
        desc = (cog.description or "").strip() if cog else ""
        lines.append(f"**{name}** - {desc}" if desc else f"**{name}**")

    return f"{header}\n\n\n## Categories\n\n" + "\n".join(lines)


def category_text(bot: commands.Bot, name: str) -> str:
    cog = bot.get_cog(name)
    if cog is None:
        return f"# {name}\n\nThis category isn't loaded."

    # a cog can ship its own hand-written help page (see cogs/antinuke.py)
    custom = getattr(cog, "help_text", None)
    if custom:
        return custom.replace("{p}", bot.prefix_display)[:3900]

    text = f"# {name}\n\n{(cog.description or '').strip()}\n\n## Commands\n\n"
    cmds = sorted(cog.get_commands(), key=lambda c: c.name)
    if not cmds:
        return text + "No commands yet."

    lines = [
        f"`{bot.prefix_display}{c.qualified_name}` - {c.short_doc or 'No description'}"
        for c in cmds
    ]
    return (text + "\n".join(lines))[:3800]  # components allow ~4000 chars of text


class HelpSelect(ui.Select):
    def __init__(self, layout: "HelpLayout", current: str):
        options = [
            discord.SelectOption(label="Overview", value="Overview", default=current == "Overview")
        ]
        options += [
            discord.SelectOption(label=n, value=n, default=current == n) for n in CATEGORIES
        ]
        super().__init__(placeholder="Overview", options=options)
        self.layout = layout

    async def callback(self, interaction: discord.Interaction):
        self.layout.render(self.values[0])
        await interaction.response.edit_message(view=self.layout)


class HelpLayout(ui.LayoutView):
    """Help menu built from Components V2 (needs discord.py 2.6+)."""

    def __init__(self, bot: commands.Bot, author: discord.abc.User):
        super().__init__(timeout=120)
        self.bot = bot
        self.author = author
        self.message: discord.Message | None = None
        self.select: HelpSelect | None = None
        self.render("Overview")

    def render(self, page: str):
        self.clear_items()
        text = overview_text(self.bot) if page == "Overview" else category_text(self.bot, page)

        container = ui.Container()
        container.add_item(ui.TextDisplay(text))
        container.add_item(ui.Separator())

        self.select = HelpSelect(self, page)
        row = ui.ActionRow()
        row.add_item(self.select)
        container.add_item(row)

        self.add_item(container)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.author.id:
            await interaction.response.send_message(
                "This menu isn't yours. Run the help command yourself.", ephemeral=True
            )
            return False
        return True

    async def on_timeout(self):
        if self.select:
            self.select.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass


class General(commands.Cog, name="General"):
    """Help shortcuts and bot latency"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="help", aliases=["h", "commands"])
    async def help_command(self, ctx: commands.Context, *, category: str | None = None):
        """Show the help menu, or a single category."""
        view = HelpLayout(self.bot, ctx.author)
        if category:
            match = next((n for n in CATEGORIES if n.lower() == category.lower()), None)
            if match:
                view.render(match)
        view.message = await ctx.send(view=view)

    @commands.command(name="ping", aliases=["latency"])
    async def ping(self, ctx: commands.Context):
        """Show the bot's latency."""
        await ctx.send(f"Pong! `{round(self.bot.latency * 1000)}ms`")


async def setup(bot: commands.Bot):
    await bot.add_cog(General(bot))
